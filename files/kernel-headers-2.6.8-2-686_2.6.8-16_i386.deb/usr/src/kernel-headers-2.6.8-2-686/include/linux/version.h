#define UTS_RELEASE "2.6.8-2-686"
#define LINUX_VERSION_CODE 132616
#define KERNEL_VERSION(a,b,c) (((a) << 16) + ((b) << 8) + (c))
