/*
listme_relay.c - DSBL listme@dsbl.org email relay
Copyright (C) 2002 Ian Gulliver

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <firestring.h>
#include "dsbl.h"

#define LINELEN 513

int main() {
	char line[LINELEN];
	if (fork()) {
		FILE *scumbagin;

		scumbagin = fdopen(0,"r");

		while (1) {
			if (fgets(line,LINELEN,scumbagin) == NULL)
				exit(1);
			if (firestring_strncasecmp(line,"DSBL LISTME:",12) == 0) {
				line[strlen(line) - 2] = '\0';
				firestring_strncat(line," ",LINELEN);
				firestring_strncat(line,getenv("SERVERIP"),LINELEN);
				firestring_strncat(line,"\r\n",LINELEN);
			}
			write(7,line,strlen(line));
		}
	} else {
		int i;
		while (1) {
			i = read(6,line,LINELEN);
			if (i <= 0)
				exit(1);
			if (write(1,line,i) != i)
				exit(1);
		}
	}

	return 0;
}

