/*
process_listme.c - DSBL listme@dsbl.org email processor
Copyright (C) 2002 Ian Gulliver

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include <mysql/mysql.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/file.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <firedns.h>
#include <firestring.h>
#include "dsbl.h"

#define BUFLEN 8192
#define LINELEN 513
#define NUM_CLIENTS 100
#define max(a,b) (a > b ? a : b)

char tempbuf[256];
int l;

MYSQL mysql;
char globaluser[256] = "";

int idletime;

int process_message(char *message, char *transport, char *sourceip, char *cookie, char *extended, char *helo, char *clientip, int cnum);

time_t lastcheck;
time_t curtime;

struct s_client {
	struct in_addr clientip;
	time_t lasttalk;
	int clientsock;
	char buffer[LINELEN];
	int bufloc;

	int indata;
	int inblock;
	int linesin;

	char message[BUFLEN];
	int messageloc;

	char helo[LINELEN];
	char transport[LINELEN];
	char sourceip[LINELEN];
	char outputip[LINELEN];
	char extended[LINELEN];
	char cookie[LINELEN];

	int setoutput;
};

struct s_client clients[NUM_CLIENTS];

void closeidle() {
	int i;
	time_t now;
	time(&now);
	if (now == lastcheck)
		return;
	lastcheck = now;

	for (i = 0; i < NUM_CLIENTS; i++) {
		if (clients[i].clientsock == -1)
			continue;
		if (clients[i].lasttalk + idletime > now)
			continue;
#define TIMEOUT "552 idle timeout exceeded\r\n"
		fprintf(stderr,"%d: [%d] idle timeout exceeded from %s\n",(int) curtime,i,firedns_ntoa4(&clients[i].clientip));
		write(clients[i].clientsock,TIMEOUT,sizeof(TIMEOUT) - 1);
		close(clients[i].clientsock);
		clients[i].clientsock = -1;
	}
}

void parseread(int clientnum) {
	char *nextline;
	char *linestart;
	char *tempchr;
	int i;

	time(&clients[clientnum].lasttalk);
	clients[clientnum].buffer[clients[clientnum].bufloc] = '\0';
	/* ignore nulls */
	clients[clientnum].bufloc = strlen(clients[clientnum].buffer);
	 
	while (1) {
		clients[clientnum].buffer[clients[clientnum].bufloc] = '\0';
		nextline = strchr(clients[clientnum].buffer,'\n');
		if (nextline == NULL)
			break;
		nextline[0] = '\0';
		if (nextline > clients[clientnum].buffer && nextline[-1] == '\r')
			nextline[-1] = '\0';
		nextline++;
		if (clients[clientnum].indata == 1) {
#define THANKS "250 ok\r\n"
			if (clients[clientnum].buffer[0] == '.' && clients[clientnum].buffer[1] == '\0') {
				clients[clientnum].indata = 0;
				l = sprintf(tempbuf,"250 listed [%s]\r\n",firedns_ntoa4(&clients[clientnum].clientip));
				write(clients[clientnum].clientsock,tempbuf,l);
				clients[clientnum].message[clients[clientnum].messageloc] = '\0';
				if (clients[clientnum].helo[0] != '\0' &&
						clients[clientnum].transport[0] != '\0' &&
						clients[clientnum].sourceip[0] != '\0' &&
						clients[clientnum].cookie[0] != '\0' &&
						clients[clientnum].extended[0] != '\0') {
					char clientip[sizeof(struct in_addr)];
					struct in_addr *sourceip;
					if (clients[clientnum].outputip[0] == '\0' || ((sourceip = firedns_aton4(clients[clientnum].outputip)) == NULL))
						memcpy(clientip,&clients[clientnum].clientip,sizeof(struct in_addr));
					else
						memcpy(clientip,sourceip,sizeof(struct in_addr));
					sourceip = firedns_aton4(clients[clientnum].sourceip);
					if (sourceip != NULL) {
						process_message(clients[clientnum].message,clients[clientnum].transport,(char *) sourceip,clients[clientnum].cookie,clients[clientnum].extended,clients[clientnum].helo,clientip,clientnum);
					}
				}

			} else {
#define TOOLONG "552 message too large\r\n"
				if (clients[clientnum].messageloc >= BUFLEN - 2) {
					write(clients[clientnum].clientsock,TOOLONG,sizeof(TOOLONG) - 1);
					close(clients[clientnum].clientsock);
					clients[clientnum].clientsock = -1;
					return;
				}
				if (clients[clientnum].linesin > 0)
					clients[clientnum].linesin++;
				if (clients[clientnum].linesin == 0 && strcmp(clients[clientnum].buffer,"") == 0)
					clients[clientnum].linesin = 1;
				linestart = clients[clientnum].buffer;
				if (clients[clientnum].linesin == 0) {
					if (linestart[0] == ' ' || linestart[0] == '\t') {
						while (linestart[0] == ' ' || linestart[0] == '\t')
							linestart++;
						clients[clientnum].message[clients[clientnum].messageloc++] = ' ';
					} else {
						clients[clientnum].message[clients[clientnum].messageloc++] = '\n';
					}
				} else {
					clients[clientnum].message[clients[clientnum].messageloc++] = '\n';
				}
				i = strlen(linestart);
				if (clients[clientnum].messageloc + i >= BUFLEN - 1) {
					write(clients[clientnum].clientsock,TOOLONG,sizeof(TOOLONG) - 1);
					close(clients[clientnum].clientsock);
					clients[clientnum].clientsock = -1;
					return;
				}
				memcpy(&clients[clientnum].message[clients[clientnum].messageloc],linestart,i);
				clients[clientnum].messageloc += i;
				if (clients[clientnum].inblock == 2) {
					if (strncmp(clients[clientnum].buffer,"DSBL END",8) == 0)
						clients[clientnum].inblock = 0;
					else {
						if (strlen(clients[clientnum].extended) + strlen(clients[clientnum].buffer) >= BUFLEN - 2) {
							write(clients[clientnum].clientsock,TOOLONG,sizeof(TOOLONG) - 1);
							close(clients[clientnum].clientsock);
							clients[clientnum].clientsock = -1;
							return;
						}
						if (clients[clientnum].extended[0] != '\0')
							strcat(clients[clientnum].extended,"\n");
						strcat(clients[clientnum].extended,clients[clientnum].buffer);
					}
				} else if (clients[clientnum].inblock == 1) {
					strcpy(clients[clientnum].cookie,clients[clientnum].buffer);
					clients[clientnum].inblock = 2;
				} else {
					if (clients[clientnum].linesin > 0 && clients[clientnum].linesin < 8 && strncmp(clients[clientnum].buffer,"DSBL LISTME: ",13) == 0) {
						clients[clientnum].inblock = 1;
						tempchr = strchr(&clients[clientnum].buffer[13],' ');
						if (tempchr) {
							char *tempchr2;
							tempchr[0] = '\0';
							strcpy(clients[clientnum].transport,&clients[clientnum].buffer[13]);
							tempchr++;
							tempchr2 = strchr(tempchr,' ');
							if (tempchr2 != NULL && clients[clientnum].setoutput == 1) {
								tempchr2[0] = '\0';
								tempchr2++;
								strcpy(clients[clientnum].outputip,tempchr2);
							}
							strcpy(clients[clientnum].sourceip,tempchr);
						}
					}
				}
			}
		} else {
			if (firestring_strncasecmp(clients[clientnum].buffer,"QUIT",4) == 0) {
#define PARTING "221 goodbye\r\n"
				write(clients[clientnum].clientsock,PARTING,sizeof(PARTING) - 1);
				close(clients[clientnum].clientsock);
				clients[clientnum].clientsock = -1;
				return;
			} else if (firestring_strncasecmp(clients[clientnum].buffer,"HELO",4) == 0) {
				write(clients[clientnum].clientsock,THANKS,sizeof(THANKS) - 1);
				if (clients[clientnum].buffer[4] != '\0')
					strcpy(clients[clientnum].helo,&clients[clientnum].buffer[5]);
			} else if (firestring_strncasecmp(clients[clientnum].buffer,"MAIL FROM:",10) == 0) {
				write(clients[clientnum].clientsock,THANKS,sizeof(THANKS) - 1);
			} else if (firestring_strncasecmp(clients[clientnum].buffer,"RCPT TO:",8) == 0) {
				write(clients[clientnum].clientsock,THANKS,sizeof(THANKS) - 1);
			} else if (firestring_strncasecmp(clients[clientnum].buffer,"RSET",4) == 0) {
				write(clients[clientnum].clientsock,THANKS,sizeof(THANKS) - 1);
			} else if (firestring_strncasecmp(clients[clientnum].buffer,"DATA",4) == 0) {
				clients[clientnum].indata = 1;
				clients[clientnum].linesin = 0;
				clients[clientnum].inblock = 0;
				clients[clientnum].messageloc = 0;
				clients[clientnum].transport[0] = '\0';
				clients[clientnum].extended[0] = '\0';
				clients[clientnum].sourceip[0] = '\0';
				clients[clientnum].outputip[0] = '\0';
				clients[clientnum].cookie[0] = '\0';
#define GOAHEAD "354 go ahead\r\n"
				write(clients[clientnum].clientsock,GOAHEAD,sizeof(GOAHEAD) - 1);
			} else {
#define HUH "502 huh?\r\n"
				write(clients[clientnum].clientsock,HUH,sizeof(HUH) - 1);
			}
		}
		clients[clientnum].bufloc -= (nextline - clients[clientnum].buffer);
		memmove(clients[clientnum].buffer,nextline,clients[clientnum].bufloc);
	}
}

int gettrusted(char *cookie) {
	char query[1024];
	MYSQL_RES *res;
	MYSQL_ROW row;
	int i;

	globaluser[0] = '\0';
	i = firestring_snprintf(query,1024,"SELECT trusted,username FROM cookies WHERE cookie='");
	i += mysql_real_escape_string(&mysql,&query[i],cookie,strlen(cookie));
	strcpy(&query[i],"';");
	i += 2;

	if (mysql_real_query(&mysql,query,i) != 0) {
		mysql_perror(&mysql,"SELECT trusted FROM cookies");
		exit(0);
	}

	res = mysql_store_result(&mysql);
	if (res == NULL) {
		mysql_perror(&mysql,"mysql_store_result");
		exit(0);
	}

	row = mysql_fetch_row(res);
	if (row == NULL) {
		/* invalid cookie */
		return -1;
	}

	if (row[1] != NULL) {
		i = mysql_real_escape_string(&mysql,globaluser,row[1],strlen(row[1]));
		globaluser[i] = '\0';
	}

	if (atoi(row[0]) == 1) {
		mysql_free_result(res);
		return 1;
	}

	mysql_free_result(res);
	return 0;
}

int main() {
	const char *listenip;
	int clientsperip;
	const char *temp;
	int listensock;
	struct sockaddr_in listenaddr;
	struct in_addr *ip;
	socklen_t t;
	int i, s, c, count, ipcount;
	fd_set r;

	readconf();

	listenip = firestring_conf_find(config,"listenip");
	if (listenip == NULL) {
		fprintf(stderr,"listenip not set in config.\n");
		exit(100);
	}

	temp = firestring_conf_find(config,"clientsperip");
	if (temp == NULL) {
		fprintf(stderr,"clientsperip not set in config.\n");
		exit(100);
	}

	clientsperip = atoi(temp);

	temp = firestring_conf_find(config,"idletime");
	if (temp == NULL) {
		fprintf(stderr,"idletime not set in config.\n");
		exit(100);
	}

	idletime = atoi(temp);

	listensock = socket(PF_INET, SOCK_STREAM, 0);

	i = 1;
	setsockopt(listensock, SOL_SOCKET, SO_REUSEADDR, (char *)&i, sizeof(i));

	listenaddr.sin_family = AF_INET;
	listenaddr.sin_port = htons(25);

	ip = firedns_aton4(listenip);
	if (ip == NULL) {
		fprintf(stderr,"listenip is not a valid IP address.\n");
		exit(100);
	}

	memcpy(&listenaddr.sin_addr.s_addr,ip,sizeof(struct in_addr));

	if (bind(listensock,(struct sockaddr *) &listenaddr,sizeof(struct sockaddr_in)) != 0) {
		perror("bind");
		exit(100);
	}

	/* start up mysql */
	startmysql(&mysql);

	if (listen(listensock,256) != 0) {
		perror("listen");
		exit(100);
	}

	for (i = 0; i < NUM_CLIENTS; i++)
		clients[i].clientsock = -1;

	while (1) {
		FD_ZERO(&r);
		FD_SET(listensock,&r);

		s = listensock;

		closeidle();

		for (i = 0; i < NUM_CLIENTS; i++)
			if (clients[i].clientsock != -1) {
				FD_SET(clients[i].clientsock,&r);
				s = max(s,clients[i].clientsock);
			}

		s = select(s+1,&r,NULL,NULL,NULL);
		time(&curtime);

		if (FD_ISSET(listensock,&r)) {
			for (i = 0; i < NUM_CLIENTS; i++)
				if (clients[i].clientsock == -1)
					break;
			if (i == NUM_CLIENTS) { /* out of space */
				s = accept(listensock,NULL,NULL);
#define TOOBUSY_ERROR "421 dsbl too many clients, try again later\r\n"
				write(s,TOOBUSY_ERROR,sizeof(TOOBUSY_ERROR)-1);
				close(s);
				fprintf(stderr,"too busy!!!\n");
			} else {
				t = sizeof(struct sockaddr_in);
				clients[i].clientsock = accept(listensock,(struct sockaddr *) &listenaddr,&t);
				if (fcntl(clients[i].clientsock, F_SETFL, O_NONBLOCK) != 0) {
					perror("fcntl");
					close(clients[i].clientsock);
					clients[i].clientsock = -1;
				} else {
					clients[i].bufloc = 0;
					clients[i].indata = 0;
					clients[i].helo[0] = '\0';
					memcpy(&clients[i].clientip,&listenaddr.sin_addr,sizeof(struct in_addr));
					for (c = 0, count = 0, ipcount = 0; c < NUM_CLIENTS; c++) {
						if (clients[c].clientsock != -1) {
							count++;
							if (memcmp(&clients[c].clientip,&clients[i].clientip,4) == 0)
								ipcount++;
						}
					}
#define IP_OVERFLOW "421 too many clients from your ip, try again later\r\n"
					if (ipcount > clientsperip) {
						fprintf(stderr,"%d: [%d] per-ip limit exceeded from %s\n",(int) curtime,i,firedns_ntoa4(&clients[i].clientip));
						write(clients[i].clientsock,IP_OVERFLOW,sizeof(IP_OVERFLOW) - 1);
						close(clients[i].clientsock);
						clients[i].clientsock = -1;
					}
					time(&clients[i].lasttalk);
					l = sprintf(tempbuf,"220 dsbl [%s]\r\n",firedns_ntoa4(&clients[i].clientip));
					write(clients[i].clientsock,tempbuf,l);
					fprintf(stderr,"%d: [%d] connection (%d/%d) from %s\n",(int) curtime,i,count,NUM_CLIENTS,firedns_ntoa4(&clients[i].clientip));
					clients[i].setoutput = 0;
					{
						char *item = NULL;
						char *cip = firedns_ntoa4(&clients[i].clientip);
						

						while (item = firestring_conf_find_next(config,"can_set_output",item)) {
							if (strcmp(item,cip) == 0) {
								clients[i].setoutput = 1;
								fprintf(stderr,"%d: [%d] relay site\n",(int) curtime,i);
								break;
							}
						}

					}
				}
			}
		}
		
		for (i = 0; i < NUM_CLIENTS; i++) 
			if (clients[i].clientsock != -1 && FD_ISSET(clients[i].clientsock,&r)) {
				s = read(clients[i].clientsock,&clients[i].buffer[clients[i].bufloc],LINELEN - clients[i].bufloc - 1);
				if (s <= 0) {
					close(clients[i].clientsock);
					clients[i].clientsock = -1;
				} else {
					clients[i].bufloc += s;
					parseread(i);
					if (clients[i].bufloc >= LINELEN - 1) {
#define OVERFLOW_ERROR "500 line too long\r\n"
						write(clients[i].clientsock,OVERFLOW_ERROR,sizeof(OVERFLOW_ERROR)-1);
						close(clients[i].clientsock);
						clients[i].clientsock = -1;
						fprintf(stderr,"%d: [%d] overflow from %s\n",(int) curtime,i,firedns_ntoa4(&clients[i].clientip));
					}
				}
			}

	}

	return 0;
}

int process_message(char *message, char *transport, char *sourceip, char *cookie, char *extended, char *helo, char *clientip, int cnum) {
	MYSQL_RES *res;
	MYSQL_ROW row;
	char query[BUFLEN * 6];
	char eschelo[LINELEN * 2];
	char escip[9];
	char escsourceip[9];
	char state[128];
	int trusted;
	unsigned long messageid;
	int our_multihop = 0;
	int our_singlehop = 0;
	int our_unconfirmed = 0;
	int list_multihop = 0;
	int list_singlehop = 0;
	int list_unconfirmed = 0;
	int i;

	fprintf(stderr,"%d: [%d] processing valid hit for %s\n",(int) curtime,cnum,firedns_ntoa4((struct in_addr *)clientip));

	eschelo[0] = '\0';
	if (helo != NULL) {
		i = mysql_real_escape_string(&mysql,eschelo,helo,strlen(helo));
		eschelo[i] = '\0';
	}

	trusted = gettrusted(cookie);

	if (trusted == -1)
		return -1;

	i = 4;
	while (clientip[i - 1] == ' ')
		i--;

	i = mysql_real_escape_string(&mysql,escip,clientip,i);
	escip[i] = '\0';

	i = mysql_real_escape_string(&mysql,escsourceip,sourceip,4);
	escsourceip[i] = '\0';

	i = firestring_snprintf(query,BUFLEN * 6,"INSERT INTO messages SET username='%s',ip='%s',sourceip='%s',message='",globaluser,escip,escsourceip);
	i += mysql_real_escape_string(&mysql,&query[i],message,strlen(message));

	strcpy(&query[i],"',transport='");
	i += 13;
	i += mysql_real_escape_string(&mysql,&query[i],transport,strlen(transport));

	strcpy(&query[i],"',extended='");
	i += 12;
	i += mysql_real_escape_string(&mysql,&query[i],extended,strlen(extended));

	i += firestring_snprintf(&query[i],BUFLEN * 6,"';",sourceip);

	if (mysql_real_query(&mysql,query,i) != 0) {
		mysql_perror(&mysql,"INSERT INTO messages");
		exit(0);
	}

	messageid = mysql_insert_id(&mysql);
	if (messageid == 0) {
		fprintf(stderr,"No insert ID returned!\n");
		exit(0);
	}

	our_unconfirmed = 1;
	if (trusted == 1) {
		if (memcmp(clientip,sourceip,4) == 0 || strstr(message,"Received:") == NULL)
			our_singlehop = 1;
		else
			our_multihop = 1;
	}

	i = firestring_snprintf(query,BUFLEN * 6,"SELECT state,helo,unconfirmed,singlehop,multihop FROM list WHERE ip='%s';",escip);

	if (mysql_real_query(&mysql,query,i) != 0) {
		mysql_perror(&mysql,"SELECT FROM list");
		exit(0);
	}

	res = mysql_store_result(&mysql);
	if (res == NULL) {
		mysql_perror(&mysql,"mysql_store_result");
		exit(0);
	}

	row = mysql_fetch_row(res);
	if (row != NULL) {
		strcpy(state,row[0]);

		list_unconfirmed = atoi(row[2]);
		list_singlehop = atoi(row[3]);
		list_multihop = atoi(row[4]);

		if (helo != NULL && (row[1] == NULL || strcmp(row[1],helo) != 0)) {
			mysql_free_result(res);
			i = firestring_snprintf(query,BUFLEN * 6, "UPDATE list SET helo='%s' WHERE ip='%s';",eschelo,escip);
	
			if (mysql_real_query(&mysql,query,i) != 0) {
				mysql_perror(&mysql,"UPDATE list SET helo");
				exit(0);
			}
		} else
			mysql_free_result(res);
	}

#define max(a,b) (a > b ? a : b)

	our_unconfirmed = max(our_unconfirmed,list_unconfirmed);
	our_singlehop = max(our_singlehop,list_singlehop);
	our_multihop = max(our_multihop,list_multihop);
	
	if (row == NULL) /* not listed, insert */
		i = firestring_snprintf(query,BUFLEN * 6,"INSERT INTO list SET state='Listed',helo='%s',ip='%s',unconfirmed='%d',singlehop='%d',multihop='%d';",eschelo,escip,our_unconfirmed,our_singlehop,our_multihop);
	else /* listed, update state */
		i = firestring_snprintf(query,BUFLEN * 6,"UPDATE list SET state='Listed',unconfirmed='%d',singlehop='%d',multihop='%d' WHERE ip='%s';",our_unconfirmed,our_singlehop,our_multihop,escip);

	if (mysql_real_query(&mysql,query,i) != 0) {
		/* not really an error, probably a race */
	}

	if (strcmp(state,"Awaiting Removal") == 0) {
		list_unconfirmed = 0;
		list_singlehop = 0;
		list_multihop = 0;
	}

	if (our_unconfirmed != list_unconfirmed) {
		i = firestring_snprintf(query,BUFLEN * 6,"INSERT INTO history SET action='Listed in Unconfirmed',data='%y',ip='%s';",messageid,escip);

		if (mysql_real_query(&mysql,query,i) != 0) {
			mysql_perror(&mysql,"INSERT INTO history SET action='Listed in Unconfirmed'");
			exit(0);
		}
	}

	if (our_singlehop != list_singlehop) {
		i = firestring_snprintf(query,BUFLEN * 6,"INSERT INTO history SET action='Listed in Singlehop',data='%y',ip='%s';",messageid,escip);

		if (mysql_real_query(&mysql,query,i) != 0) {
			mysql_perror(&mysql,"INSERT INTO history SET action='Listed in Singlehop'");
			exit(0);
		}
	}

	if (our_multihop != list_multihop) {
		i = firestring_snprintf(query,BUFLEN * 6,"INSERT INTO history SET action='Listed in Multihop',data='%y',ip='%s';",messageid,escip);

		if (mysql_real_query(&mysql,query,i) != 0) {
			mysql_perror(&mysql,"INSERT INTO history SET action='Listed in Multihop'");
			exit(0);
		}
	}

	i = firestring_snprintf(query,BUFLEN * 6,"SELECT ip FROM removal_cookies WHERE ip='%s';",escip);

	if (mysql_real_query(&mysql,query,i) != 0) {
		mysql_perror(&mysql,"SELECT FROM removal_cookies");
		exit(0);
	}

	res = mysql_store_result(&mysql);
	if (res == NULL) {
		mysql_perror(&mysql,"mysql_store_result");
		exit(0);
	}

	row = mysql_fetch_row(res);
	if (row != NULL) {
		/* removal currently in progress */

		/* insert history noting deletion */
		i = firestring_snprintf(query,BUFLEN * 6,"INSERT INTO history SET action='Removal Cancelled by Relisting',data='%y',ip='%s';",messageid,escip);

		if (mysql_real_query(&mysql,query,i) != 0) {
			mysql_perror(&mysql,"INSERT INTO history SET action='Removal Cancelled by Relisting'");
			exit(0);
		}

		/* remove cookie */
		i = firestring_snprintf(query,BUFLEN * 6,"DELETE FROM removal_cookies WHERE ip='%s';",escip);

		if (mysql_real_query(&mysql,query,i) != 0) {
			mysql_perror(&mysql,"DELETE FROM removal_cookies");
			exit(0);
		}

	}

	return 0;
}
