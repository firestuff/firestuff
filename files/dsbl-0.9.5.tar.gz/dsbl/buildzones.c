/*
buildzones.c - DSBL zone builder
Copyright (C) 2002 Ian Gulliver

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include <sys/time.h>
#include <sys/file.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <mysql/mysql.h>
#include <firestring.h>
#include <firedns.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <time.h>
#include "dsbl.h"


#define TTL 2048

#define AR "Awaiting Removal"
#define SQL "SELECT ip,unconfirmed,singlehop,multihop,state FROM list;"

int main() {
	MYSQL mysql;
	MYSQL_RES *res;
	MYSQL_ROW row;
	FILE *rbldns;
	FILE *rbldns_multihop;
	FILE *rbldns_trusted;
	FILE *awaiting_removal;
	char ntoastring[16];
	char *ipstring;
	char bip[4];
	struct in_addr in;
	char message[1024];
	char ourmessage[1024];
	int i,o,len;
	unsigned long *lengths;

	const char *tempdir,
		*zonedir,
		*unconfirmed_zone,
		*confirmed_zone,
		*multihop_zone,
		*unconfirmed_nameserver,
		*confirmed_nameserver,
		*multihop_nameserver,
		*zone_contact,
		*zone_message;

	readconf();

	tempdir = firestring_conf_find(config,"tempdir");
	if (tempdir == NULL) {
		fprintf(stderr,"tempdir not set in config.\n");
		exit(100);
	}

	zonedir = firestring_conf_find(config,"zonedir");
	if (zonedir == NULL) {
		fprintf(stderr,"zonedir not set in config.\n");
		exit(100);
	}

	unconfirmed_zone = firestring_conf_find(config,"unconfirmed_zone");
	if (unconfirmed_zone == NULL) {
		fprintf(stderr,"unconfirmed_zone not set in config.\n");
		exit(100);
	}

	confirmed_zone = firestring_conf_find(config,"confirmed_zone");
	if (confirmed_zone == NULL) {
		fprintf(stderr,"confirmed_zone not set in config.\n");
		exit(100);
	}

	multihop_zone = firestring_conf_find(config,"multihop_zone");
	if (confirmed_zone == NULL) {
		fprintf(stderr,"multihop_zone not set in config.\n");
		exit(100);
	}

	unconfirmed_nameserver = firestring_conf_find(config,"unconfirmed_nameserver");
	if (unconfirmed_nameserver == NULL) {
		fprintf(stderr,"unconfirmed_nameserver not set in config.\n");
		exit(100);
	}

	confirmed_nameserver = firestring_conf_find(config,"confirmed_nameserver");
	if (confirmed_nameserver == NULL) {
		fprintf(stderr,"confirmed_nameserver not set in config.\n");
		exit(100);
	}

	multihop_nameserver = firestring_conf_find(config,"multihop_nameserver");
	if (confirmed_nameserver == NULL) {
		fprintf(stderr,"multihop_nameserver not set in config.\n");
		exit(100);
	}

	zone_contact = firestring_conf_find(config,"zone_contact");
	if (zone_contact == NULL) {
		fprintf(stderr,"zone_contact not set in config.\n");
		exit(100);
	}

	zone_message = firestring_conf_find(config,"zone_message");
	if (zone_message == NULL) {
		fprintf(stderr,"zone_message not set in config.\n");
		exit(100);
	}

	/* start up mysql */
	startmysql(&mysql);

	rbldns = fopen(firestring_concat(tempdir,"/rbldns-",unconfirmed_zone,NULL),"w");
	if (rbldns == NULL) {
		perror("fopen(rbldns-unconfirmed_zone)");
		exit(1);
	}

	/* lock just the rbldns file, to make sure we're the only one touching this stuff */
	i = fileno(rbldns);
	if (i == -1) {
		perror("fileno(rbldns)");
		exit(1);
	}

	if (flock(i,LOCK_EX|LOCK_NB) != 0) {
		perror("flock(rbldns)");
		exit(1);
	}

	rbldns_trusted = fopen(firestring_concat(tempdir,"/rbldns-",confirmed_zone,NULL),"w");
	if (rbldns_trusted == NULL) {
		perror("fopen(rbldns-confirmed_zone)");
		exit(1);
	}

	rbldns_multihop = fopen(firestring_concat(tempdir,"/rbldns-",multihop_zone,NULL),"w");
	if (rbldns_multihop == NULL) {
		perror("fopen(rbldns-multihop_zone)");
		exit(1);
	}

	awaiting_removal = fopen(firestring_concat(tempdir,"/awaiting_removal",NULL),"w");
	if (awaiting_removal == NULL) {
		perror("fopen(awaiting_removal)");
		exit(1);
	}

	/* load SQL data */
	if (mysql_real_query(&mysql,SQL,sizeof(SQL) - 1) != 0) {
		mysql_perror(&mysql,"mysql_real_query");
		exit(1);
	}

	res = mysql_store_result(&mysql);
	if (res == NULL) {
		mysql_perror(&mysql,"mysql_store_result");
		exit(1);
	}

	/* put the tops of the files */
	if (fprintf(rbldns,":127.0.0.2:%s\n#$TTL %ds\n#$SOA 10m a.list.ns.dsbl.org admin.dsbl.org %ld 10m 5m 1d 10m\n",zone_message,TTL,time(NULL)) <= 0) {
		perror("fprintf(rbldns-unconfirmed_zone)");
		exit(1);
	}

	if (fprintf(rbldns_trusted,":127.0.0.2:%s\n#$TTL %ds\n#$SOA 10m a.list.ns.dsbl.org admin.dsbl.org %ld 10m 5m 1d 10m\n",zone_message,TTL,time(NULL)) <= 0) {
		perror("fprintf(rbldns-confirmed_zone)");
		exit(1);
	}

	if (fprintf(rbldns_multihop,":127.0.0.2:%s\n#$TTL %ds\n#$SOA 10m a.list.ns.dsbl.org admin.dsbl.org %ld 10m 5m 1d 10m\n",zone_message,TTL,time(NULL)) <= 0) {
		perror("fprintf(rbldns-multihop_zone)");
		exit(1);
	}

	/* put the actual data */
	i = 0;
	o = 0;
	strncpy(message,zone_message,1024);
	len = strlen(message);
	message[--len] = '\0';
	for (i = 0; i < len; i++) {
		switch(message[i]) {
			case ':':
				ourmessage[o++] = '\\';
				ourmessage[o++] = '0';
				ourmessage[o++] = '7';
				ourmessage[o++] = '2';
				break;
			default:
				ourmessage[o++] = message[i];
				break;
		}
	}
	ourmessage[o] = '\0';

	while ((row = mysql_fetch_row(res)) != NULL) {
		lengths = mysql_fetch_lengths(res);

		memset(&in.s_addr,32,4);
		memcpy(&in.s_addr,row[0],lengths[0]);

		firestring_strncpy(ntoastring,firedns_ntoa4(&in),16);
		bip[0] = ((char *) &in.s_addr)[3];
		bip[1] = ((char *) &in.s_addr)[2];
		bip[2] = ((char *) &in.s_addr)[1];
		bip[3] = ((char *) &in.s_addr)[0];
		memcpy(&in.s_addr,bip,4);
		ipstring = firedns_ntoa4(&in);  

		if (lengths[4] == sizeof(AR) - 1 && memcmp(row[4],AR,sizeof(AR) - 1) == 0) {
			/* this IP is awaiting removal */
			if (fprintf(awaiting_removal,"%s\n",ntoastring) <= 0) {
				perror("fprintf(awaiting_removal)");
				exit(1);
			}
		}

		if (atoi(row[1]) == 1) { /* unconfirmed */
			if (fprintf(rbldns,"%s\n",ntoastring) <= 0) {
				perror("fprintf(rbldns-unconfirmed_zone)");
				exit(1);
			}
		}

		if (atoi(row[2]) == 1) { /* singlehop */
			if (fprintf(rbldns_trusted,"%s\n",ntoastring) <= 0) {
				perror("fprintf(rbldns-confirmed_zone)");
				exit(1);
			}
		}

		if (atoi(row[3]) == 1) { /* multihop */
			if (fprintf(rbldns_multihop,"%s\n",ntoastring) <= 0) {
				perror("fprintf(rbldns-confirmed_zone)");
				exit(1);
			}
		}
	}

	/* free sql result */
	mysql_free_result(res);
		
	/* close file handles */
	fclose(rbldns);
	fclose(rbldns_trusted);
	fclose(rbldns_multihop);
	fclose(awaiting_removal);

	/* atomically rename files */
	if (rename(firestring_concat(tempdir,"/rbldns-",unconfirmed_zone,NULL),
				firestring_concat(zonedir,"/rbldns-",unconfirmed_zone,NULL)) != 0) {
		perror("rename(rbldns-unconfirmed_zone)");
		exit(1);
	}

	if (rename(firestring_concat(tempdir,"/rbldns-",confirmed_zone,NULL),
				firestring_concat(zonedir,"/rbldns-",confirmed_zone,NULL)) != 0) {
		perror("rename(rbldns-confirmed_zone)");
		exit(1);
	}

	if (rename(firestring_concat(tempdir,"/rbldns-",multihop_zone,NULL),
				firestring_concat(zonedir,"/rbldns-",multihop_zone,NULL)) != 0) {
		perror("rename(rbldns-multihop_zone)");
		exit(1);
	}

	if (rename(firestring_concat(tempdir,"/awaiting_removal",NULL),
				firestring_concat(zonedir,"/awaiting_removal",NULL)) != 0) {
		perror("rename(awaiting_removal)");
		exit(1);
	}

	return 0;
}

