/*
contacts.c - DSBL contact email address finder
Copyright (C) 2002 Ian Gulliver

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <firedns.h>
#include <firestring.h>

#define DOMAIN_DEPTH 10
#define max(a,b) (a > b ? a : b)

/* waste a good chunk of ram */
char addresses[64][2][256];
int numadd = 0;
int fds_a[64];
int fds_mx[64];
int gotrecord[64];

int checkaddress(char *user, char *domain) {
	int i;
	for (i = 0; i < numadd; i++) {
		if (firestring_strcasecmp(addresses[i][0],user) == 0 && firestring_strcasecmp(addresses[i][1],domain) == 0)
			return 1;
	}
	return 0;
}

void addaddress(char *user, char *domain) {
	char * tempchr;
	int i;
	if (strlen(domain) > 255)
		return;
	tempchr = strchr(domain,'.');
	if (tempchr == NULL)
		return;
	if (checkaddress(user,domain))
		return;
	firestring_strncpy(addresses[numadd][0],user,256);
	firestring_strncpy(addresses[numadd][1],domain,256);
	fds_a[numadd] = firedns_getip4(domain);
	fds_mx[numadd] = firedns_getmx(domain);
	numadd++;
	tempchr = domain;
	for (i = 0; i < DOMAIN_DEPTH; i++) {
		tempchr = strchr(tempchr,'.');
		if (tempchr == NULL)
			return;
		tempchr++;
		if (checkaddress(user,tempchr))
			return;
		if (strchr(tempchr,'.') == NULL)
			return;
		firestring_strncpy(addresses[numadd][0],user,256);
		firestring_strncpy(addresses[numadd][1],tempchr,256);
		fds_a[numadd] = firedns_getip4(tempchr);
		fds_mx[numadd] = firedns_getmx(tempchr);
		numadd++;
	}
}

void gotresponse_a(int i) {
	char *result;
	result = firedns_getresult(fds_a[i]);
	fds_a[i] = -1;
	if (result != NULL) {
		gotrecord[i] = 1;
		return;
	}
	if (fds_mx[i] != -1)
		return;
	if (gotrecord[i] == 1)
		return;
	addresses[i][0][0] = '\0';
	return;
}

void gotresponse_mx(int i) {
	char *result;
	result = firedns_getresult(fds_mx[i]);
	fds_mx[i] = -1;
	if (result != NULL) { /* result is positive */
		gotrecord[i] = 1;
		return;
	}
	if (fds_a[i] != -1) /* still waiting for other response */
		return;
	if (gotrecord[i] == 1) /* other response already came back positive */
		return;
	addresses[i][0][0] = '\0'; /* we're not gonna use this addy */
	return;
}

void done() {
	int i;
	for (i = 0; i < numadd; i++) {
		if (fds_a[i] != -1)
			gotresponse_a(i);
		if (fds_mx[i] != -1)
			gotresponse_mx(i);
		if (addresses[i][0][0] == '\0')
			continue;
		printf("%s@%s\n",addresses[i][0],addresses[i][1]);
	}
	exit(0);
}

int main(int argc, char **argv) {
	int reversefd;
	struct in_addr *intemp, in;
	int i;
	int n;
	fd_set r,w;
	struct timeval tv;
	char *tempchr;
	char reversename[256] = "";

	if (argc < 2) {
		fprintf(stderr,"Usage: %s <ip> [<helo domain>]\n",argv[0]);
		exit(100);
	}

	intemp = firedns_aton4(argv[1]);
	if (intemp == NULL) {
		fprintf(stderr,"Invalid IP\n");
		exit(100);
	}
	memcpy(&in,intemp,sizeof(struct in_addr));

	reversefd = firedns_getname4(&in);

	firestring_strncpy(addresses[numadd][0],"postmaster",256);
	firestring_snprintf(addresses[numadd][1],256,"[%s]",argv[1]);
	numadd++;
	firestring_strncpy(addresses[numadd][0],"abuse",256);
	firestring_snprintf(addresses[numadd][1],256,"[%s]",argv[1]);
	numadd++;

	for (i = 0; i < 64; i++) {
		fds_a[i] = fds_mx[i] = -1;
		gotrecord[i] = 0;
	}

	if (argc >= 3) {
		addaddress("postmaster",argv[2]);
		addaddress("abuse",argv[2]);
	}

	while (1) {
		n = -1;
		FD_ZERO(&r);
		FD_ZERO(&w);
		if (reversefd != -1) {
			FD_SET(reversefd,&r);
			n = max(n,reversefd);
		}
		for (i = 1; i < numadd; i++) {
			if (fds_a[i] != -1) {
				FD_SET(fds_a[i],&r);
				n = max(n,fds_a[i]);
			}
			if (fds_mx[i] != -1) {
				FD_SET(fds_mx[i],&r);
				n = max(n,fds_mx[i]);
			}
		}
		tv.tv_sec = 5;
		tv.tv_usec = 0;
		if (n < 0)
			done();
		n = select(n + 1,&r,&w,NULL,&tv);
		if (n <= 0)
			done();
		if (reversefd != -1 && FD_ISSET(reversefd,&r)) {
			tempchr = firedns_getresult(reversefd);
			reversefd = -1;
			if (tempchr != NULL) {
				addaddress("postmaster",tempchr);
				addaddress("abuse",tempchr);
				firestring_strncpy(reversename,tempchr,256);
			}
		}
		for (i = 1; i < numadd; i++) {
			if (fds_a[i] != -1 && FD_ISSET(fds_a[i],&r))
				gotresponse_a(i);
			if (fds_mx[i] != -1 && FD_ISSET(fds_mx[i],&r))
				gotresponse_mx(i);
		}
	}
}
