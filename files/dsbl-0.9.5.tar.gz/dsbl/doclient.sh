#!/bin/sh

export SERVERIP="$TCPREMOTEIP"

exec tcpclient mx.listme.dsbl.org 25 ./listme_relay
