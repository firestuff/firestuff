/*
dsbl.c - DSBL shared functions
Copyright (C) 2002 Ian Gulliver

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#define DSBL_C

#include <mysql/mysql.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <firestring.h>
#include "dsbl.h"

struct s_zone *zone_head = NULL;
struct firestring_conf_t *config;

void mysql_perror(MYSQL *m, char *string) {
	fprintf(stderr,"%s: %s\n",string,mysql_error(m));
}

void readconf() {
	char *homedir;

	homedir = getenv("HOME");
	if (homedir != NULL) {
		config = firestring_conf_parse(firestring_concat(homedir,"/.dsblrc",NULL));
		if (config != NULL)
			return;
	}
	
	config = firestring_conf_parse(CONFDIR "/dsbl.conf");
	if (config == NULL) {
		fprintf(stderr,"Cannot open ~/.dsblrc or " CONFDIR "/dsbl.conf\n");
		exit(100);
	}
}

void startmysql(MYSQL *m) {
	const char *mysql_host,
		*mysql_user,
		*mysql_pass,
		*mysql_db;

	if (mysql_init(m) == NULL) {
		mysql_perror(m,"mysql_init");
		exit(1);
	}

	mysql_host = firestring_conf_find(config,"mysql_host");
	if (mysql_host == NULL) {
		fprintf(stderr,"mysql_host not set in config.\n");
		exit(100);
	}

	mysql_user = firestring_conf_find(config,"mysql_user");
	if (mysql_user == NULL) {
		fprintf(stderr,"mysql_user not set in config.\n");
		exit(100);
	}

	mysql_pass = firestring_conf_find(config,"mysql_pass");
	if (mysql_pass == NULL) {
		fprintf(stderr,"mysql_pass not set in config.\n");
		exit(100);
	}

	mysql_db = firestring_conf_find(config,"mysql_db");
	if (mysql_db == NULL) {
		fprintf(stderr,"mysql_db not set in config.\n");
		exit(100);
	}
	
	if (mysql_real_connect(m,mysql_host,mysql_user,mysql_pass,mysql_db,0,NULL,0) == NULL) {
		mysql_perror(m,"mysql_real_connect");
		exit(1);
	}
}
