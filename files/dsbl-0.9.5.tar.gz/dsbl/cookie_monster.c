/*
cookie_monster.c - DSBL cookie server
Copyright (C) 2002 Ian Gulliver

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include <mysql/mysql.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/file.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <firestring.h>
#include "dsbl.h"

MYSQL mysql;
char globaluser[256] = "";

#define COOKIE_LENGTH 32
unsigned char *gencookie() {
	static unsigned char cookie[COOKIE_LENGTH+1];
	int f;

	f = open("/dev/urandom",O_RDONLY);
	if (f == -1) {
		perror("open");
		exit(1);
	}

	if (read(f,cookie,COOKIE_LENGTH) != COOKIE_LENGTH) {
		perror("read");
		exit(1);
	}

	close(f);

	for (f = 0; f < COOKIE_LENGTH; f++) {
		cookie[f] %= 64;
		cookie[f] += 35;
		if (cookie[f] > 35)
			cookie[f] += 13;
		if (cookie[f] > 57)
			cookie[f] += 7;
		if (cookie[f] > 90)
			cookie[f] += 4;
		if (cookie[f] > 95)
			cookie[f] += 1;
	}

	cookie[COOKIE_LENGTH] = '\0';

	return cookie;
}

int gettrusted(char *username, char *password) {
	char query[1024];
	MYSQL_RES *res;
	MYSQL_ROW row;
	int i;
	strcpy(query,"SELECT trusted,password,MD5('");
	i = strlen(query);
	i += mysql_real_escape_string(&mysql,&query[i],password,strlen(password));
	strcpy(&query[i],"') FROM trusted WHERE username='");
	i = strlen(query);
	i += mysql_real_escape_string(&mysql,&query[i],username,strlen(username));
	strcpy(&query[i],"';");
	i += 2;

	if (mysql_real_query(&mysql,query,i) != 0) {
		mysql_perror(&mysql,"SELECT FROM trusted");
		exit(1);
	}

	res = mysql_store_result(&mysql);
	if (res == NULL) {
		mysql_perror(&mysql,"mysql_use_result");
		exit(1);
	}

	row = mysql_fetch_row(res);
	if (row == NULL) {
		mysql_free_result(res); /* invalid username */
		return 0;
	}

	if (row[1] == NULL || row[2] == NULL) {
		mysql_free_result(res); /* null password or wierdness */
		return 0;
	}

	if (strcmp(row[1],row[2]) != 0) {
		mysql_free_result(res); /* invalid password */
		return 0;
	}

	i = mysql_real_escape_string(&mysql,globaluser,username,strlen(username));
	globaluser[i] = '\0';
	
	if (atoi(row[0]) == 1) {
		mysql_free_result(res);
		return 1;
	}

	mysql_free_result(res);
	return 0;
}

void addcookie(char *cookie, int trusted) {
	char query[1024];
	int i;

	i = firestring_snprintf(query,1024,"INSERT INTO cookies SET cookie='%s',trusted='%d',username='%s';",cookie,trusted,globaluser);
	if (mysql_real_query(&mysql,query,i) != 0) {
		mysql_perror(&mysql,"INSERT INTO cookies");
		exit(1);
	}
}

int main() {
	char username[65];
	char password[65];
	int trusted;
	char *cookie;

	if (fgets(username,65,stdin) == NULL)
		exit(1);
	username[strlen(username) - 1] = '\0';

	if (fgets(password,65,stdin) == NULL)
		exit(1);
	password[strlen(password) - 1] = '\0';

	readconf();

	/* start up mysql */
	startmysql(&mysql);

	/* ok, we have a username and password */
	trusted = gettrusted(username,password);

	/* generate cookie */
	cookie = (char *) gencookie();

	/* add cookie to database with trusted value */
	addcookie(cookie,trusted);

	/* dump cookie out */
	printf("%s",cookie);
	return 0;
}
