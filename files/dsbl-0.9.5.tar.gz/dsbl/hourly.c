/*
hourly.c - DSBL hourly cleanups
Copyright (C) 2002 Ian Gulliver

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include <mysql/mysql.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/file.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <firestring.h>
#include "dsbl.h"

#define CLEAN_AWAITING "SELECT ip FROM list WHERE (state='Awaiting Removal' or state='Awaiting Removal from Unconfirmed') AND lastchange < DATE_SUB(NOW(),INTERVAL 24 HOUR);"
#define CLEAN_COOKIES "DELETE FROM cookies WHERE lastchange < DATE_SUB(NOW(),INTERVAL 6 HOUR);"
#define CLEAN_REMOVAL_COOKIES "DELETE FROM removal_cookies WHERE lastchange < DATE_SUB(NOW(),INTERVAL 7 DAY);"
#define CLEAN_CHECKSUMS "DELETE FROM checksums WHERE lastchange < DATE_SUB(NOW(),INTERVAL 7 DAY);"

int main() {
	MYSQL mysql;
	MYSQL_RES *res;
	MYSQL_ROW row;
	char query[1024];
	int i;
	unsigned long *lengths;

	readconf();

	/* start up mysql */
	startmysql(&mysql);

	/* clean awaiting */
	if (mysql_real_query(&mysql,CLEAN_AWAITING,sizeof(CLEAN_AWAITING) - 1) != 0) {
		mysql_perror(&mysql,"mysql_real_query");
		exit(1);
	}

	res = mysql_store_result(&mysql);
	if (res == NULL)
		exit(0);

	while ((row = mysql_fetch_row(res)) != NULL) {
		lengths = mysql_fetch_lengths(res);
		/* add history for removal */
		i = firestring_snprintf(query,1024,"INSERT INTO history SET action='Removed',ip='");
		i += mysql_real_escape_string(&mysql,&query[i],row[0],lengths[0]);
		strcpy(&query[i],"';");
		i += 2;

		if (mysql_real_query(&mysql,query,i) != 0) {
			mysql_perror(&mysql,"mysql_real_query");
			exit(1);
		}

		/* remove */
		i = firestring_snprintf(query,1024,"DELETE FROM list WHERE ip='");
		i += mysql_real_escape_string(&mysql,&query[i],row[0],lengths[0]);
		strcpy(&query[i],"';");
		i += 2;

		if (mysql_real_query(&mysql,query,i) != 0) {
			mysql_perror(&mysql,"mysql_real_query");
			exit(1);
		}
	}

	if (mysql_real_query(&mysql,CLEAN_COOKIES,sizeof(CLEAN_COOKIES)-1) != 0) {
		mysql_perror(&mysql,"CLEAN COOKIES");
		exit(1);
	}

	if (mysql_real_query(&mysql,CLEAN_REMOVAL_COOKIES,sizeof(CLEAN_REMOVAL_COOKIES)-1) != 0) {
		mysql_perror(&mysql,"CLEAN REMOVAL COOKIES");
		exit(1);
	}

	if (mysql_real_query(&mysql,CLEAN_CHECKSUMS,sizeof(CLEAN_CHECKSUMS)-1) != 0) {
		mysql_perror(&mysql,"CLEAN CHECKSUMS");
		exit(1);
	}

	return 0;
}

