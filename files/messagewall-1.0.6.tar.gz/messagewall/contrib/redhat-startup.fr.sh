#!/bin/bash
#
# MessageWall : filtre les emails avec les extensions des mails ainsi qu'un fichier de d�finition de virus, utilis� aussi par OpenAntivirus (source des fichiers de d�finition des virus
# Install� par Gauret

# Source function library.
. /etc/rc.d/init.d/functions


# Source networking configuration.
. /etc/sysconfig/network

PATH=/usr/bin:/sbin:/bin:/usr/sbin:/usr/local/bin
export PATH

# Check that networking is up.
[ ${NETWORKING} = "no" ] && exit 0

# start function
startmw() {
    echo -n "D�marrage de MessageWall : "
    echo $(date +%d%b%Y) > /var/run/messagewall.startdate
# Used for stats, and so that a restart doesn't overwrite the previous log
    /usr/local/bin/messagewall 2> /var/log/mail/messagewall-$(date +%d%b%Y).log &
    echo "MessageWall d�marr� !"
}

# stop function
stopmw() {
    echo -n "Arr�t de MessageWall : "
    /usr/local/bin/messagewallctl stop
    echo "MessageWall arr�t� !"
}


case "$1" in
start)
    startmw
    ;;

stop)
    stopmw
    ;;

restart)
    stopmw
    startmw
    ;;

status)
    status messagewall
    ;;

stats)
    /usr/local/bin/messagewallstats /var/log/mail/messagewall-$(cat /var/run/messagewall.startdate).log
    ;;

*)
    echo "Usage: $0 {start|stop|status|restart|stats}"
    exit 1
esac

exit 0
