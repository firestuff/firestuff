#define CONFIG_ACPI 1
