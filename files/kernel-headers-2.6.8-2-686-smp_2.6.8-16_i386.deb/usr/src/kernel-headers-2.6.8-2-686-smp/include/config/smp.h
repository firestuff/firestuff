#define CONFIG_SMP 1
