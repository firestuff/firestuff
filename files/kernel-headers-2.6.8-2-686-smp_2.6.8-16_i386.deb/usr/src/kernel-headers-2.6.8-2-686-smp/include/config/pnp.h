#define CONFIG_PNP 1
