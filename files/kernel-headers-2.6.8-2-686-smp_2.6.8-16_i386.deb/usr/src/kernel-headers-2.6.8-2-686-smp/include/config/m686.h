#define CONFIG_M686 1
