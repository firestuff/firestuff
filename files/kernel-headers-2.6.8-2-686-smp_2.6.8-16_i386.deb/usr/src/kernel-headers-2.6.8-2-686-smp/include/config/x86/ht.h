#define CONFIG_X86_HT 1
