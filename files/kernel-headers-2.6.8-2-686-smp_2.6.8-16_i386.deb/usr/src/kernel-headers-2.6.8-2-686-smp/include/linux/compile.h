/* This file is auto generated, version 1 */
#define UTS_MACHINE "i386"
#define UTS_VERSION "#1 SMP Thu May 19 17:27:55 JST 2005"
#define LINUX_COMPILE_TIME "17:27:55"
#define LINUX_COMPILE_BY "horms"
#define LINUX_COMPILE_HOST "tabatha.lab.ultramonkey.org"
#define LINUX_COMPILE_DOMAIN "lab.ultramonkey.org"
#define LINUX_COMPILER "gcc version 3.3.5 (Debian 1:3.3.5-12)"
