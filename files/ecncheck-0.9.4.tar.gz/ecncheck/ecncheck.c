/*
ecncheck.c - ECN tester
Copyright (C) 2004 Ian Gulliver

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <netinet/in.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <firestring.h>
#include <firedns.h>
#include "cksum.h"

/* configuration is really just here */
#define PROBE_DEPTH 32
#define PROBE_WAIT 5
#define DNS_WAIT 5

#define PACKET_LENGTH 40
#ifdef HAVE_IPV6
#define PACKET6_LENGTH 60
#endif
#define max(a,b) (a > b ? a : b)

int packets;
int xml = 0;
int slow = 0;
int names = 1;
#ifdef HAVE_IPV6
int ipv6 = 0;
#endif

struct icmp_type {
	int type;
	int code;
	char *text;
};

struct icmp_type icmp_types[] = {
	{ 0, 0, "Echo reply" },
	{ 3, 0, "Destination network unreachable" },
	{ 3, 1, "Destination host unreachable" },
	{ 3, 2, "Destination protocol unreachable" },
	{ 3, 3, "Destination port unreachable" },
	{ 3, 4, "Fragmentation needed & don't-fragment set" },
	{ 3, 5, "Source route failed" },
	{ 3, 6, "Destination network unknown" },
	{ 3, 7, "Destination host unknown" },
	{ 3, 8, "Source host isolated" },
	{ 3, 9, "Network administratively prohibited" },
	{ 3, 10, "Host administratively prohibited" },
	{ 3, 11, "Network unreachable for TOS" },
	{ 3, 12, "Host unreachable for TOS" },
	{ 3, 13, "Communication administratively prohibited" },
	{ 4, 0, "Source quench" },
	{ 5, 0, "Redirect datagram for the network" },
	{ 5, 0, "Redirect datagram for the host" },
	{ 5, 0, "Redirect datagram for the TOS & network" },
	{ 5, 0, "Redirect datagram for the TOS & host" },
	{ 8, 0, "Echo request" },
	{ 9, 0, "Router advertisement" },
	{ 10, 0, "Router selection" },
	{ 11, 0, "Time to live exceeded in transit" },
	{ 11, 1, "Fragment reassembly time exceeded" },
	{ 12, 0, "Parameter problem" },
	{ 12, 1, "Missing a required option" },
	{ 12, 2, "Bad length" },
	{ 13, 0, "Timestamp request" },
	{ 14, 0, "Timestamp reply" },
	{ 15, 0, "Information request" },
	{ 16, 0, "Information reply" },
	{ 17, 0, "Address mask request" },
	{ 18, 0, "Address mask reply" },
	{ 30, 0, "Traceroute" },
	{ 0 }
};

#ifdef HAVE_IPV6
struct icmp_type icmp6_types[] = {
	{ 1, 0, "No route to destination" },
	{ 1, 1, "Communication with destination administratively prohibited" },
	{ 1, 3, "Address unreachable" },
	{ 1, 4, "Port unreachable" },
	{ 2, 0, "Packet too big" },
	{ 3, 0, "Hop limit excdeed in transit" },
	{ 3, 1, "Fragment reassembly time exceeded" },
	{ 4, 0, "Erroneous header field encountered" },
	{ 4, 1, "Unrecognized next header type encountered" },
	{ 4, 2, "Unrecognized IPv6 option encountered" },
	{ 128, 0, "Echo request" },
	{ 129, 0, "Echo reply" },
	{ 0 }
};
#endif

unsigned char template_packet[PACKET_LENGTH] = 
/* IP Header */

/*     4 version
 *      5 32bit words long
 *         0 type of service
 *             0 total length (filled in by kernel)
 *                     0 identification (filled in by kernel)
 *                             0 flags
 *                              0 fragment offset
 *                                     0 TTL (we'll set it later)
 *                                         6 protocol (TCP)
 *                                             0 header checksum (filled in by kernel) */
    "\x45\x00\x00\x00\x00\x00\x00\x00\x00\x06\x00\x00"

/*     0 source address (filled in by kernel)
 *                     0 destination address (we'll set it later) */
    "\x00\x00\x00\x00\x00\x00\x00\x00"

/* TCP Header */

/*     0 source port (we'll set it later)
 *             0 destination port (we'll set it later)
 *                     0 sequence number (we'll set it later)
 *                                     0 acknowledgment number */
 
    "\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

/*     5 offset
 *      0 reserved
 *         2 flags (SYN, we'll set ECN later)
 *             32767 window
 *                     0 checksum (we'll set it later)
 *                             0 urgent */

    "\x50\x02\x7f\xff\x00\x00\x00\x00";

#ifdef HAVE_IPV6
unsigned char template_packet6[PACKET6_LENGTH] =

/*
 *     6 version
 *      0  0 traffic class
 *          0 flow label
 *                     20 payload length
 *                             6 protocol (TCP)
 *                                 0 TTL (we'll set it later) */
    "\x60\x00\x00\x00\x00\x14\x06\x00"
    
/* source address */
    "\x00\x00\x00\x00\x00\x00\x00\x00"
    "\x00\x00\x00\x00\x00\x00\x00\x00"

/* destination address */
    "\x00\x00\x00\x00\x00\x00\x00\x00"
    "\x00\x00\x00\x00\x00\x00\x00\x00"

/* TCP Header */

/*     0 source port (we'll set it later)
 *             0 destination port (we'll set it later)
 *                     0 sequence number (we'll set it later)
 *                                     0 acknowledgment number */
 
    "\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

/*     5 offset
 *      0 reserved
 *         2 flags (SYN, we'll set ECN later)
 *             32767 window
 *                     0 checksum (we'll set it later)
 *                             0 urgent */

    "\x50\x02\x7f\xff\x00\x00\x00\x00";
#endif

#define CONNECTION_ACCEPTED 0x01
#define CONNECTION_REFUSED  0x02
#define CONNECTION_ECN      0x04
#define CONNECTION_INVALID  0x08

struct net_object {
	int ttl;
	struct in_addr ip;
#ifdef HAVE_IPV6
	struct in6_addr ip6;
#endif
	int flags_type;
	int code;
	char name[256];
	char hostname[256];
};

struct net_object noecn_low_tcp = { .ttl = PROBE_DEPTH };
struct net_object noecn_high_icmpttl = { .ttl = -1 };
struct net_object noecn_high_icmpother = { .ttl = -1 };
struct net_object ecn_low_tcp = { .ttl = PROBE_DEPTH };
struct net_object ecn_high_icmpttl = { .ttl = -1 };
struct net_object ecn_high_icmpother = { .ttl = -1 };

void handle_name(int fd, struct net_object *o) {
	char *name;
	name = firedns_getresult(fd);
	if (name != NULL) {
#ifdef HAVE_IPV6
		if (ipv6)
			firestring_snprintf(o->name,256,"%s [%s]",name,firedns_ntoa6(&o->ip6));
		else
#endif
			firestring_snprintf(o->name,256,"%s [%s]",name,firedns_ntoa4(&o->ip));
		firestring_strncpy(o->hostname,name,256);
	}
}

void lookup_names() {
#define REAL_SENDLOOKUP(fd,o) o.hostname[0] = '\0'; firestring_snprintf(o.name,256,"[%s]",firedns_ntoa4(&o.ip)); if (o.ttl == -1 || o.ttl == PROBE_DEPTH) fd = -1; else { fd = firedns_getname4(&o.ip); n = max(n,fd); c++; }
#define REAL_SENDLOOKUP6(fd,o) o.hostname[0] = '\0'; firestring_snprintf(o.name,256,"[%s]",firedns_ntoa6(&o.ip6)); if (o.ttl == -1 || o.ttl == PROBE_DEPTH) fd = -1; else { fd = firedns_getname6(&o.ip6); n = max(n,fd); c++; }
#ifdef HAVE_IPV6
#	define SENDLOOKUP(fd,o) if (ipv6) { REAL_SENDLOOKUP6(fd,o) } else { REAL_SENDLOOKUP(fd,o) }
#else
#	define SENDLOOKUP(fd,o) REAL_SENDLOOKUP(fd,o)
#endif
#define REAL_NOLOOKUP(o) o.hostname[0] = '\0'; firestring_snprintf(o.name,256,"[%s]",firedns_ntoa4(&o.ip));
#define REAL_NOLOOKUP6(o) o.hostname[0] = '\0'; firestring_snprintf(o.name,256,"[%s]",firedns_ntoa6(&o.ip6));
#ifdef HAVE_IPV6
#	define NOLOOKUP(o) if (ipv6) { REAL_NOLOOKUP6(o) } else { REAL_NOLOOKUP(o) }
#else
#	define NOLOOKUP(o) REAL_NOLOOKUP(o)
#endif
	int n = -1,c = 0;
	time_t start;
	int fd_noecn_low_tcp,
		fd_noecn_high_icmpttl,
		fd_noecn_high_icmpother,
		fd_ecn_low_tcp,
		fd_ecn_high_icmpttl,
		fd_ecn_high_icmpother;

	if (names == 0) {
		NOLOOKUP(noecn_low_tcp)
		NOLOOKUP(noecn_high_icmpttl)
		NOLOOKUP(noecn_high_icmpother)
		NOLOOKUP(ecn_low_tcp)
		NOLOOKUP(ecn_high_icmpttl)
		NOLOOKUP(ecn_high_icmpother)
		return;
	}

	SENDLOOKUP(fd_noecn_low_tcp,noecn_low_tcp)
	SENDLOOKUP(fd_noecn_high_icmpttl,noecn_high_icmpttl)
	SENDLOOKUP(fd_noecn_high_icmpother,noecn_high_icmpother)
	SENDLOOKUP(fd_ecn_low_tcp,ecn_low_tcp)
	SENDLOOKUP(fd_ecn_high_icmpttl,ecn_high_icmpttl)
	SENDLOOKUP(fd_ecn_high_icmpother,ecn_high_icmpother)

	time(&start);
	while (1) {
		int l;
		struct timeval tv;
		fd_set readset;

		tv.tv_sec = DNS_WAIT - (time(NULL) - start);
		if (tv.tv_sec <= 0)
			break;
		tv.tv_usec = 0;

		FD_ZERO(&readset);
#define SETME(fd,s) if (fd != -1) FD_SET(fd,&s)
		SETME(fd_noecn_low_tcp,readset);
		SETME(fd_noecn_high_icmpttl,readset);
		SETME(fd_noecn_high_icmpother,readset);
		SETME(fd_ecn_low_tcp,readset);
		SETME(fd_ecn_high_icmpttl,readset);
		SETME(fd_ecn_high_icmpother,readset);

		if (n == -1)
			break;
		l = select(n+1,&readset,NULL,NULL,&tv);
		if (l <= 0)
			break;
#define CHECKRESPONSE(fd,s,o) if (fd != -1 && FD_ISSET(fd,&s)) { handle_name(fd,&o); fd = -1; }
		CHECKRESPONSE(fd_noecn_low_tcp,readset,noecn_low_tcp)
		CHECKRESPONSE(fd_noecn_high_icmpttl,readset,noecn_high_icmpttl)
		CHECKRESPONSE(fd_noecn_high_icmpother,readset,noecn_high_icmpother)
		CHECKRESPONSE(fd_ecn_low_tcp,readset,ecn_low_tcp)
		CHECKRESPONSE(fd_ecn_high_icmpttl,readset,ecn_high_icmpttl)
		CHECKRESPONSE(fd_ecn_high_icmpother,readset,ecn_high_icmpother)

		c -= l;
		if (c == 0)
			break;
	}

}

char *icmp_name(int type, int code) {
	int i;
	struct icmp_type *types = icmp_types;
#ifdef HAVE_IPV6
	if (ipv6)
		types = icmp6_types;
#endif
	
	for (i = 0; types[i].text != NULL; i++)
		if (types[i].type == type && types[i].code == code)
			return types[i].text;

	return "Unknown ICMP type/code";
}

int print_tcp_object(struct net_object *o) {
	int ret;

	if (o->ttl == PROBE_DEPTH) {
		if (xml)
			printf(" result=\"no_response\" />");
		else
			printf("No response");
		return 0;
	}

	if ((o->flags_type & 0x02) && (o->flags_type & 0x10)) {
		ret = CONNECTION_ACCEPTED;
		if (xml)
			printf(" result=\"accepted\"");
		else
			printf("Connection accepted ");
	} else if (o->flags_type & 0x04) {
		ret = CONNECTION_REFUSED;
		if (xml)
			printf(" result=\"refused\"");
		else
			printf("Connection refused ");
	} else {
		ret = CONNECTION_INVALID;
		if (xml)
			printf(" result=\"invalid\"");
		else
			printf("Invalid TCP response ");
	}

	if (o->flags_type & 0x40) {
		ret |= CONNECTION_ECN;
		if (xml)
			printf(" ecn=\"yes\"");
		else
			printf("(with ECN enabled) ");
	} else if (xml)
		printf(" ecn=\"no\"");

	if (xml) {
#ifdef HAVE_IPV6
		if (ipv6)
			printf(" hop=\"%d\"><host ip=\"%s\"",o->ttl,firedns_ntoa6(&o->ip6));
		else
#endif
			printf(" hop=\"%d\"><host ip=\"%s\"",o->ttl,firedns_ntoa4(&o->ip));
		if (o->hostname[0] != '\0')
			printf(" name=\"%s\"",o->hostname);
		printf(" /></connection_attempt>");
	} else
		printf("by %s at hop #%d",o->name,o->ttl);

	return ret;
}

void print_icmpttl_object(struct net_object *o) {
	if (o->ttl == -1) {
		if (xml)
			printf(" result=\"no_response\" />");
		else
			printf("No responses");
		return;
	}

	if (xml) {
#ifdef HAVE_IPV6
		if (ipv6)
			printf(" hop=\"%d\"><host ip=\"%s\"",o->ttl,firedns_ntoa6(&o->ip6));
		else
#endif
			printf(" hop=\"%d\"><host ip=\"%s\"",o->ttl,firedns_ntoa4(&o->ip));
		if (o->hostname[0] != '\0')
			printf(" name=\"%s\"",o->hostname);
		printf(" /></last_hop>");
	} else
		printf("%s at hop #%d",o->name,o->ttl);
}

void print_icmpother_object(struct net_object *o) {
	if (o->ttl == -1) {
		if (xml)
			printf(" result=\"no_response\" />");
		else
			printf("No responses");
		return;
	}

	if (xml) {
#ifdef HAVE_IPV6
		if (ipv6)
			printf(" hop=\"%d\" type=\"%d\" code=\"%d\">%s\n"
				"		<host ip=\"%s\"",o->ttl,o->flags_type,o->code,icmp_name(o->flags_type,o->code),firedns_ntoa6(&o->ip6));
		else
#endif
			printf(" hop=\"%d\" type=\"%d\" code=\"%d\">%s\n"
				"		<host ip=\"%s\"",o->ttl,o->flags_type,o->code,icmp_name(o->flags_type,o->code),firedns_ntoa4(&o->ip));
		if (o->hostname[0] != '\0')
			printf(" name=\"%s\"",o->hostname);
		printf(" /></other_icmp>");
	} else
		printf("Type %d, code %d (%s) from %s at hop #%d",o->flags_type,o->code,icmp_name(o->flags_type,o->code),o->name,o->ttl);
}

void set_object(struct net_object *object, int ttl, struct in_addr *ip, int flags_type, int code) {
	object->ttl = ttl;
	memcpy(&object->ip,ip,4);
	object->flags_type = flags_type;
	object->code = code;
}

#ifdef HAVE_IPV6
void set_object6(struct net_object *object, int ttl, struct in6_addr *ip, int flags_type, int code) {
	object->ttl = ttl;
	memcpy(&object->ip6,ip,16);
	object->flags_type = flags_type;
	object->code = code;
}

int send_packet6(int r, int source_port, struct sockaddr_in6 *dest, unsigned char ttl, int ecn, unsigned char *pseudo_header) {
	unsigned char packet[PACKET6_LENGTH];
	__u16 sum;

	memcpy(packet,template_packet6,PACKET6_LENGTH);
	packet[7] = ttl;
	if (ecn)
		packet[53] |= 0xc0;

	/* randomize sequence number so we're not easy to filter */
	packet[44] = rand();
	packet[45] = rand();
	packet[46] = rand();
	packet[47] = rand();

	/* set source port */
	source_port += ttl;
	if (ecn != 0)
		source_port += 256;

	packet[40] = source_port / 256;
	packet[41] = source_port % 256;

	memcpy(&pseudo_header[40],&packet[40],PACKET6_LENGTH - 40);
	sum = htons(cksum((__u16 *)pseudo_header,PACKET6_LENGTH));

	packet[56] = sum >> 8;
	packet[57] = sum & 0xff;

	sendto(r,packet,PACKET6_LENGTH,0,(struct sockaddr *) dest,sizeof(struct sockaddr_in6));

	if (slow)
		nanosleep(&(struct timespec) { 0, 100000 },NULL);

	return 0;
}
#endif

int send_packet(int r, int source_port, struct sockaddr_in *dest, unsigned char ttl, int ecn, unsigned char *pseudo_header) {
	unsigned char packet[PACKET_LENGTH];
	__u16 sum;

	memcpy(packet,template_packet,PACKET_LENGTH);
	packet[8] = ttl;
	if (ecn)
		packet[33] |= 0xc0;

	/* randomize sequence number so we're not easy to filter */
	packet[24] = rand();
	packet[25] = rand();
	packet[26] = rand();
	packet[27] = rand();

	/* set source port */
	source_port += ttl;
	if (ecn != 0)
		source_port += 256;

	packet[20] = source_port / 256;
	packet[21] = source_port % 256;

	memcpy(&pseudo_header[12],&packet[20],PACKET_LENGTH - 20);
	sum = htons(cksum((__u16 *)pseudo_header,PACKET_LENGTH - 8));

	packet[36] = sum >> 8;
	packet[37] = sum & 0xff;

	sendto(r,packet,PACKET_LENGTH,0,(struct sockaddr *) dest,sizeof(struct sockaddr_in));

	if (slow)
		nanosleep(&(struct timespec) { 0, 100000 },NULL);

	return 0;
}

#ifdef HAVE_IPV6
void handle_tcp6(struct sockaddr_in6 *source, int source_port, struct sockaddr_in6 *dest, int dest_port, struct sockaddr_in6 *message_from, unsigned char *buf, int l) {
	int tcp_offset = 0;
	int ecn, ttl;
	if (l < 20)
		return;

	/* check 2: is it coming from our destination? */
	if (memcmp(&message_from->sin6_addr,&dest->sin6_addr,16) != 0)
		return;

	/* check 3: is it coming from our destination port? */
	if ((buf[tcp_offset] << 8) + buf[tcp_offset + 1] != dest_port)
		return;

	/* check 4: is it going to our destination range? */
	{
		int sport = (buf[tcp_offset + 2] << 8) + buf[tcp_offset + 3];
		int base;

		ttl = sport % 256;
		base = sport - ttl;
		
		if (base == source_port)
			ecn = 0;
		else if (base == source_port + 256)
			ecn = 1;
		else 
			return;
	}

	/* this is a tcp response, meaning we hit the actual host */
	packets--;

	{
		struct net_object *o = ecn ? &ecn_low_tcp : &noecn_low_tcp;
		if (ttl < o->ttl)
			set_object6(o,ttl,&message_from->sin6_addr,buf[tcp_offset + 13],0);
	}
}

void handle_icmp6(struct sockaddr_in6 *source, int source_port, struct sockaddr_in6 *dest, int dest_port, struct sockaddr_in6 *message_from, unsigned char *buf, int l) {
	int packet_offset = 8;
	int ecn, ttl;

	if (l < 68)
		return;

	/* check 1: did it come from our source ip? */
	if (memcmp(&buf[packet_offset + 8],&source->sin6_addr,16) != 0)
		return; /* not our ip */

	/* check 2: better be tcp */
	if (buf[packet_offset + 6] != 6)
		return; /* not tcp */

	/* check 3: is the destination ip ours? */
	if (memcmp(&buf[packet_offset + 24],&dest->sin6_addr,4) != 0)
		return;

	/* check 4: is the destination port ours? */
	if ((buf[packet_offset + 42] << 8) + buf[packet_offset + 43] != dest_port)
		return;

	/* check 5: is the source port in our range? */
	{
		int sport = (buf[packet_offset + 40] << 8) + buf[packet_offset + 41];
		int base;

		ttl = sport % 256;
		base = sport - ttl;

		if (base == source_port)
			ecn = 0;
		else if (base == source_port + 256)
			ecn = 1;
		else 
			return;
	}

	/* we should get one icmp in response to any tcp that got dropped, so this *should* work out */
	packets--;

	{
		struct net_object *o;

		if (buf[0] == 3 && buf[1] == 0) /* standard traceroute response */
			o = ecn ? &ecn_high_icmpttl : &noecn_high_icmpttl;
		else 
			o = ecn ? &ecn_high_icmpother : &noecn_high_icmpother;

		if (ttl > o->ttl)
			set_object6(o,ttl,&message_from->sin6_addr,buf[0],buf[1]);
	}
}

#endif

void handle_tcp(struct sockaddr_in *source, int source_port, struct sockaddr_in *dest, int dest_port, struct sockaddr_in *message_from, unsigned char *buf, int l) {
	int tcp_offset;
	int ecn, ttl;
	if (l < 40)
		return;

	tcp_offset = (buf[0] & 0x0f) * 4;

	/* check 1: is it going to our source ip? */
	if (memcmp(&buf[16],&source->sin_addr,4) != 0)
		return;

	/* check 2: is it coming from our destination? */
	if (memcmp(&buf[12],&dest->sin_addr,4) != 0)
		return;

	/* check 3: is it coming from our destination port? */
	if ((buf[tcp_offset] << 8) + buf[tcp_offset + 1] != dest_port)
		return;

	/* check 4: is it going to our destination range? */
	{
		int sport = (buf[tcp_offset + 2] << 8) + buf[tcp_offset + 3];
		int base;

		ttl = sport % 256;
		base = sport - ttl;
		
		if (base == source_port)
			ecn = 0;
		else if (base == source_port + 256)
			ecn = 1;
		else 
			return;
	}

	/* this is a tcp response, meaning we hit the actual host */
	packets--;

	{
		struct net_object *o = ecn ? &ecn_low_tcp : &noecn_low_tcp;
		if (ttl < o->ttl)
			set_object(o,ttl,&message_from->sin_addr,buf[tcp_offset + 13],0);
	}
}

void handle_icmp(struct sockaddr_in *source, int source_port, struct sockaddr_in *dest, int dest_port, struct sockaddr_in *message_from, unsigned char *buf, int l) {
	int packet_offset;
	int ecn, ttl;

	if (l < 56)
		return;

	packet_offset = (buf[0] & 0x0f) * 4;
	
	/* check 1: did it come from our source ip? */
	if (memcmp(&buf[packet_offset + 20],&source->sin_addr,4) != 0)
		return; /* not our ip */

	/* check 2: better be tcp */
	if (buf[packet_offset + 17] != 6)
		return; /* not tcp */

	/* check 3: is the destination ip ours? */
	if (memcmp(&buf[packet_offset + 24],&dest->sin_addr,4) != 0)
		return;

	/* check 4: is the destination port ours? */
	if ((buf[packet_offset + 30] << 8) + buf[packet_offset + 31] != dest_port)
		return;

	/* check 5: is the source port in our range? */
	{
		int sport = (buf[packet_offset + 28] << 8) + buf[packet_offset + 29];
		int base;

		ttl = sport % 256;
		base = sport - ttl;

		if (base == source_port)
			ecn = 0;
		else if (base == source_port + 256)
			ecn = 1;
		else 
			return;
	}

	/* we should get one icmp in response to any tcp that got dropped, so this *should* work out */
	packets--;

	{
		struct net_object *o;

		if (buf[20] == 11 && buf[21] == 0) /* standard traceroute response */
			o = ecn ? &ecn_high_icmpttl : &noecn_high_icmpttl;
		else 
			o = ecn ? &ecn_high_icmpother : &noecn_high_icmpother;

		if (ttl > o->ttl)
			set_object(o,ttl,&message_from->sin_addr,buf[20],buf[21]);
	}
}

/* attempt to find a source ip */
struct in_addr *find_local_ip(struct sockaddr_in *dest) {
	int s,i;
	static struct sockaddr_in source;

	s = socket(PF_INET,SOCK_DGRAM,0);
	if (s == -1) {
		perror("socket");
		exit(102);
	}

	if (connect(s,(struct sockaddr *)dest,sizeof(struct sockaddr_in)) != 0) {
		perror("connect");
		exit(102);
	}

	i = sizeof(struct sockaddr_in);
	if (getsockname(s,(struct sockaddr *)&source,&i) != 0) {
		perror("getsockname");
		exit(102);
	}

	return &source.sin_addr;
}

#ifdef HAVE_IPV6
/* attempt to find a source ip */
struct in6_addr *find_local_ip6(struct sockaddr_in6 *dest) {
	int s,i;
	static struct sockaddr_in6 source;

	s = socket(PF_INET6,SOCK_DGRAM,0);
	if (s == -1) {
		perror("socket");
		exit(102);
	}

	if (connect(s,(struct sockaddr *)dest,sizeof(struct sockaddr_in6)) != 0) {
		perror("connect");
		exit(102);
	}

	i = sizeof(struct sockaddr_in6);
	if (getsockname(s,(struct sockaddr *)&source,&i) != 0) {
		perror("getsockname");
		exit(102);
	}

	return &source.sin6_addr;
}
#endif

/*
 * Return codes:
 *
 *   0 Host supports ECN
 *   1 Host doesn't support ECN but fails gracefully
 *   2 Host refuses all connections
 *   3 Host drops all connections
 *   4 Host advertises ECN support on non-ECN connections
 *   5 Host refuses ECN connections
 *   6 Host drops ECN connections
 *
 *   ( > 2 is bad with increasing badness )
 *
 * 100 Invalid syntax
 * 101 Invalid arguments
 * 102 System failure
 */
int main(int argc, char *argv[]) {
	int r,r_tcp,r_icmp;
	struct sockaddr_in dest = {0}, source = {0};
#ifdef HAVE_IPV6
	int r6,r6_tcp,r6_icmp;
	struct sockaddr_in6 dest6 = {0}, source6 = {0};
#endif
	int source_port;
	int i;
	unsigned char pseudo_header[256] = {0};
	int header = 1;

	r = socket(PF_INET, SOCK_RAW, IPPROTO_RAW);
	if (r < 0) {
		perror("socket(SOCK_RAW)");
		return 102;
	}

	r_tcp = socket(PF_INET, SOCK_RAW, IPPROTO_TCP);
	if (r_tcp < 0) {
		perror("socket(SOCK_RAW)");
		return 102;
	}

	r_icmp = socket(PF_INET, SOCK_RAW, IPPROTO_ICMP);
	if (r_icmp < 0) {
		perror("socket(SOCK_RAW)");
		return 102;
	}

#ifdef HAVE_IPV6
	r6 = socket(PF_INET6, SOCK_RAW, IPPROTO_RAW);
	if (r6 >= 0) {
		r6_tcp = socket(PF_INET6, SOCK_RAW, IPPROTO_TCP);
		if (r6_tcp < 0) {
			perror("socket(SOCK_RAW)");
			return 102;
		}

		r6_icmp = socket(PF_INET6, SOCK_RAW, IPPROTO_ICMPV6);
		if (r6_icmp < 0) {
			perror("socket(SOCK_RAW)");
			return 102;
		}
	}
#endif

	if (setuid(getuid()) != 0) {
		perror("setuid()");
		return 102;
	}
	
	if (argc == 4 && argv[1][0] == '-') {
		int i = 1;
		while (argv[1][i] != '\0') {
			switch (argv[1][i]) {
				case 'x':
					xml = 1;
					break;
				case 's':
					slow = 1;
					break;
				case 'H':
					header = 0;
					break;
				case 'N':
					names = 0;
					break;
			}
			i++;
		}
		argc--;
		argv[1] = argv[2];
		argv[2] = argv[3];
	}

	if (argc != 3) {
		printf("usage: %s [-xsNH] <dest ip> <port>\n",argv[0]);
		return 100;
	}

	srand(time(NULL)); /* this is pretty poor, but it doesn't have to be good at all */
	source_port = 1024 + (rand() % 63488); /* grab a random port >= 1024 */
	source_port -= source_port % 256; /* reduce to the nearest multiple of 256, for port coding spiffiness */

#ifdef HAVE_IPV6
	if (firedns_aton6_s(argv[1],&dest6.sin6_addr) != NULL) {
		/* IPv6 all the way */
		ipv6 = 1;

		close(r);
		close(r_tcp);
		close(r_icmp);
		if (r6 < 0) {
			printf("Unable to get an IPv6 raw socket (no IPv6 support in system?)\n");
			return 102;
		}

		dest6.sin6_port = htons(atoi(argv[2]));
		dest6.sin6_family = AF_INET6;

		memcpy(&source6.sin6_addr,find_local_ip6(&dest6),sizeof(source6.sin6_addr));

		memcpy(&template_packet6[8],&source6.sin6_addr,16);
		memcpy(&template_packet6[24],&dest6.sin6_addr,16);
		memcpy(&template_packet6[42],&dest6.sin6_port,2);
		memcpy(&pseudo_header[0],&source6.sin6_addr,16);
		memcpy(&pseudo_header[16],&dest6.sin6_addr,16);
		pseudo_header[35] = 20;
		pseudo_header[39] = 6;

		for (i = 0; i < PROBE_DEPTH; i++) {
			send_packet6(r6,source_port,&dest6,i,0,pseudo_header);
			send_packet6(r6,source_port,&dest6,i,1,pseudo_header);
		}
		packets = PROBE_DEPTH * 2;

		{
			time_t start_listen;
	
			time(&start_listen);
			while (1) {
				int l;
				unsigned char buf[256];
				struct sockaddr_in6 s;
				fd_set readset;
				struct timeval tv;
	
				FD_ZERO(&readset);
				FD_SET(r6_tcp,&readset);
				FD_SET(r6_icmp,&readset);
	
				tv.tv_sec = PROBE_WAIT - (time(NULL) - start_listen);
				if (tv.tv_sec <= 0)
					break;
				tv.tv_usec = 0;
	
				l = select(max(r6_tcp,r6_icmp) + 1,&readset,NULL,NULL,&tv);
				if (l <= 0)
					break;
	
				if (FD_ISSET(r6_icmp,&readset)) {
					i = sizeof(s);
					l = recvfrom(r6_icmp,buf,256,0,(struct sockaddr *)&s,&i);
					handle_icmp6(&source6,source_port,&dest6,ntohs(dest6.sin6_port),&s,buf,l);
				}
				
				if (FD_ISSET(r6_tcp,&readset)) {
					i = sizeof(s);
					l = recvfrom(r6_tcp,buf,256,0,(struct sockaddr *)&s,&i);
					handle_tcp6(&source6,source_port,&dest6,ntohs(dest6.sin6_port),&s,buf,l);
				}
			
				if (packets == 0)
					break;

				/* check for convergence */
				if ((ecn_high_icmpttl.ttl + 1 == ecn_low_tcp.ttl) &&
						(noecn_high_icmpttl.ttl + 1 == noecn_low_tcp.ttl))
					break;
			}
		}

		goto display;
	}
#endif
	/* IPv4 all the way */
	if (firedns_aton4_s(argv[1],&dest.sin_addr) == NULL) {
		printf("Invalid destination IP address\n");
		return 101;
	}

#ifdef HAVE_IPV6
	if (r6 >= 0)
		close(r6);
	if (r6_tcp >= 0)
		close(r6_tcp);
	if (r6_icmp >= 0)
		close(r6_icmp);
#endif

	dest.sin_port = htons(atoi(argv[2]));
	dest.sin_family = AF_INET;

	memcpy(&source.sin_addr,find_local_ip(&dest),sizeof(source.sin_addr));

	/* copy destination address and port into packet */
	memcpy(&template_packet[12],&source.sin_addr,4);
	memcpy(&template_packet[16],&dest.sin_addr,4);
	memcpy(&template_packet[22],&dest.sin_port,2);
	memcpy(&pseudo_header[0],&source.sin_addr,4);
	memcpy(&pseudo_header[4],&dest.sin_addr,4);
	pseudo_header[9] = 6;
	pseudo_header[11] = 20;

	for (i = 0; i < PROBE_DEPTH; i++) {
		send_packet(r,source_port,&dest,i,0,pseudo_header);
		send_packet(r,source_port,&dest,i,1,pseudo_header);
	}
	packets = PROBE_DEPTH * 2;

	{
		time_t start_listen;

		time(&start_listen);
		while (1) {
			int l;
			unsigned char buf[256];
			struct sockaddr_in s;
			fd_set readset;
			struct timeval tv;

			FD_ZERO(&readset);
			FD_SET(r_tcp,&readset);
			FD_SET(r_icmp,&readset);

			tv.tv_sec = PROBE_WAIT - (time(NULL) - start_listen);
			if (tv.tv_sec <= 0)
				break;
			tv.tv_usec = 0;

			l = select(max(r_tcp,r_icmp) + 1,&readset,NULL,NULL,&tv);
			if (l <= 0)
				break;

			if (FD_ISSET(r_icmp,&readset)) {
				i = sizeof(s);
				l = recvfrom(r_icmp,buf,256,0,(struct sockaddr *)&s,&i);
				handle_icmp(&source,source_port,&dest,ntohs(dest.sin_port),&s,buf,l);
			}
			
			if (FD_ISSET(r_tcp,&readset)) {
				i = sizeof(s);
				l = recvfrom(r_tcp,buf,256,0,(struct sockaddr *)&s,&i);
				handle_tcp(&source,source_port,&dest,ntohs(dest.sin_port),&s,buf,l);
			}
			
			if (packets == 0)
				break;

			/* check for convergence */
			if ((ecn_high_icmpttl.ttl + 1 == ecn_low_tcp.ttl) &&
					(noecn_high_icmpttl.ttl + 1 == noecn_low_tcp.ttl))
				break;
		}
	}

display:
	lookup_names();

	{
		int ret = 0;
#define RET(a) ret = max(ret,a)
		int ecn_tcp, noecn_tcp;

		if (xml) {
			if (header)
				printf("<?xml version=\"1.0\"?>\n");
#ifdef HAVE_IPV6
			if (ipv6)
				printf("<ecncheck time=\"%d\" source=\"%s\" destination=\"%s\" port=\"%d\">\n",(int)time(NULL),firedns_ntoa6(&source6.sin6_addr),argv[1],ntohs(dest.sin_port));
			else
#endif
				printf("<ecncheck time=\"%d\" source=\"%s\" destination=\"%s\" port=\"%d\">\n",(int)time(NULL),firedns_ntoa4(&source.sin_addr),argv[1],ntohs(dest.sin_port));
		}

		if (xml)
			printf("	<connection_attempt send_ecn=\"yes\"");
		else
			printf("With ECN:    ");
		ecn_tcp = print_tcp_object(&ecn_low_tcp);
		printf("\n");

		if (xml)
			printf("	<connection_attempt send_ecn=\"no\"");
		else
			printf("Without ECN: ");
		noecn_tcp = print_tcp_object(&noecn_low_tcp);
		printf("\n");

		if ((noecn_tcp & CONNECTION_ACCEPTED) && (ecn_tcp & CONNECTION_ACCEPTED) && (ecn_tcp & CONNECTION_ECN)) {
			if (xml)
				printf("	<notice type=\"ecn\">Host supports ECN</notice>\n");
			else
				printf("NOTICE: Host supports ECN\n");
			RET(0);
		}

		if ((noecn_tcp & CONNECTION_ACCEPTED) && (ecn_tcp & CONNECTION_ACCEPTED) && !(ecn_tcp & CONNECTION_ECN)) {
			if (xml)
				printf("	<warning type=\"no_ecn\">Host doesn't support ECN but fails gracefully</warning>\n");
			else
				printf("WARNING: Host doesn't support ECN but fails gracefully\n");
			RET(1);
		}

		if ((noecn_tcp & CONNECTION_REFUSED) && (ecn_tcp & CONNECTION_REFUSED)) {
			if (xml)
				printf("	<warning type=\"refuse\">Host refuses all connections</warning>\n");
			else
				printf("WARNING: Host refuses all connections\n");
			RET(2);
		}

		if ((noecn_tcp == 0) && (ecn_tcp == 0)) {
			if (xml)
				printf("	<error type=\"drop\">Host drops all connections</error>\n");
			else
				printf("ERROR: Host drops all connections\n");
			RET(3);
		}

		if (noecn_tcp & CONNECTION_ECN) {
			if (xml)
				printf("	<error type=\"always_ecn\">Host advertises ECN support on non-ECN connections</error>\n");
			else
				printf("ERROR: Host advertises ECN support on non-ECN connections\n");
			RET(4);
		}

		if ((ecn_tcp & CONNECTION_REFUSED) && (noecn_tcp & CONNECTION_ACCEPTED)) {
			if (xml)
				printf("	<error type=\"ecn_refuse\">Host refuses ECN connections</error>\n");
			else
				printf("ERROR: Host refuses ECN connections\n");
			RET(5);
		}

		if ((ecn_tcp == 0) && (noecn_tcp != 0)) {
			if (xml)
				printf("	<error type=\"ecn_drop\">Host drops ECN connections</error>\n");
			else
				printf("ERROR: Host drops ECN connections\n");
			RET(6);
		}

		if (ret > 2) {
			/* bad -- display more info */
			if (xml)
				printf("	<last_hop send_ecn=\"yes\"");
			else
				printf("Last prior hop reachable with ECN:    ");
			print_icmpttl_object(&ecn_high_icmpttl);
			printf("\n");

			if (xml)
				printf("	<last_hop send_ecn=\"no\"");
			else
				printf("Last prior hop reachable without ECN: ");
			print_icmpttl_object(&noecn_high_icmpttl);
			printf("\n");

			if (ecn_high_icmpother.ttl != -1) {
				if (xml)
					printf("	<other_icmp send_ecn=\"yes\"");
				else
					printf("Other ICMP message with ECN:    ");
				print_icmpother_object(&ecn_high_icmpother);
				printf("\n");
			}

			if (noecn_high_icmpother.ttl != -1) {
				if (xml)
					printf("	<other_icmp send_ecn=\"no\"");
				else
					printf("Other ICMP message without ECN: ");
				print_icmpother_object(&noecn_high_icmpother);
				printf("\n");
			}

			if (ecn_high_icmpttl.ttl != -1 && (ret == 5 || ret == 6)) {
				if (ecn_high_icmpother.ttl > max(noecn_high_icmpother.ttl,ecn_high_icmpttl.ttl)) {
					/* this ICMP is *probably* a description of the block */
					if (xml) {
#ifdef HAVE_IPV6
						if (ipv6)
							printf("	<error type=\"explicit_ecn_block\" hop=\"%d\" type=\"%d\" code=\"%d\">%s\n"
								"		<host ip=\"%s\"",ecn_high_icmpother.ttl,ecn_high_icmpother.flags_type,ecn_high_icmpother.code,icmp_name(ecn_high_icmpother.flags_type,ecn_high_icmpother.code),firedns_ntoa6(&ecn_high_icmpother.ip6));
						else
#endif
							printf("	<error type=\"explicit_ecn_block\" hop=\"%d\" type=\"%d\" code=\"%d\">%s\n"
								"		<host ip=\"%s\"",ecn_high_icmpother.ttl,ecn_high_icmpother.flags_type,ecn_high_icmpother.code,icmp_name(ecn_high_icmpother.flags_type,ecn_high_icmpother.code),firedns_ntoa4(&ecn_high_icmpother.ip));
						if (ecn_high_icmpother.hostname[0] != '\0')
							printf(" name=\"%s\"",ecn_high_icmpother.hostname);
						printf(" /></error>\n");
					} else
						printf("ERROR: %s at hop #%d appears to be explicitly blocking ECN packets with the message: %s\n",ecn_high_icmpother.name,ecn_high_icmpother.ttl,icmp_name(ecn_high_icmpother.flags_type,ecn_high_icmpother.code));
				} else {
					if (xml) {
#ifdef HAVE_IPV6
						if (ipv6)
							printf("	<error type=\"probable_ecn_%s\" last_hop=\"%d\"><host ip=\"%s\"",ret == 5 ? "refuse" : "drop",ecn_high_icmpttl.ttl,firedns_ntoa6(&ecn_high_icmpttl.ip6));
						else
#endif
							printf("	<error type=\"probable_ecn_%s\" last_hop=\"%d\"><host ip=\"%s\"",ret == 5 ? "refuse" : "drop",ecn_high_icmpttl.ttl,firedns_ntoa4(&ecn_high_icmpttl.ip));
						if (ecn_high_icmpttl.hostname[0] != '\0')
							printf(" name=\"%s\"",ecn_high_icmpttl.hostname);
						printf(" /></error>\n");
					} else
						printf("ERROR: It is likely that %s or something logically between %s and %s is erroneously %s packets with the ECN flags set.\n",ecn_high_icmpttl.name,ecn_high_icmpttl.name,argv[1],ret == 5 ? "refusing" : "dropping");
				}
			}
		}

		if (xml)
			printf("</ecncheck>\n");

		return ret;
	}
}
