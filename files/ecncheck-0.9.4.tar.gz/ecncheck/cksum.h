#define __u8 unsigned char
#define __u16 unsigned short
#define __u32 unsigned long

__u16 cksum(__u16 *buf, int nbytes);
