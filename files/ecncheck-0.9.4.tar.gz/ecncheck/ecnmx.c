/*
ecnmx.c - ECN MX lookup wrapper
Copyright (C) 2004 Ian Gulliver

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdio.h>
#include <firedns.h>
#include "firemake.h"
#include "firestring.h"

#define MAX_FDS 1024
#define max(a,b) (a > b ? a : b)

int pids[MAX_FDS];
int xml = 0;
int slow = 0;
int names = 1;

int magic_popen(struct in_addr *ip, int port, int i) {
	int f;
	int p[2];
	char portstring[32];
	char flags[10] = "-";

	if (pipe(p) != 0) {
		perror("pipe()");
		exit(102);
	}

	f = fork();
	if (f == -1) {
		perror("fork()");
		exit(102);
	} else if (f > 0) {
		pids[i] = f;
		close(p[1]);
		return p[0];
	}

	/* make stdout go into the pipe */
	close(p[0]);
	if (dup2(p[1],1) != 1) {
		perror("dup2()");
		exit(102);
	}

	firestring_snprintf(portstring,32,"%d",port);

	if (xml)
		strcat(flags,"xH");
	if (slow)
		strcat(flags,"s");
	if (!names)
		strcat(flags,"N");

	/* in the child */
	execl(BINDIR "/ecncheck","ecncheck",flags,firedns_ntoa4(ip),portstring,NULL);
	perror("execl()");
	exit(102);
}

#ifdef HAVE_IPV6
int magic_popen6(struct in6_addr *ip6, int port, int i) {
	int f;
	int p[2];
	char portstring[32];
	char flags[10] = "-";

	if (pipe(p) != 0) {
		perror("pipe()");
		exit(102);
	}

	f = fork();
	if (f == -1) {
		perror("fork()");
		exit(102);
	} else if (f > 0) {
		pids[i] = f;
		close(p[1]);
		return p[0];
	}

	/* make stdout go into the pipe */
	close(p[0]);
	if (dup2(p[1],1) != 1) {
		perror("dup2()");
		exit(102);
	}

	firestring_snprintf(portstring,32,"%d",port);

	if (xml)
		strcat(flags,"xH");
	if (slow)
		strcat(flags,"s");
	if (!names)
		strcat(flags,"N");

	/* in the child */
	execl(BINDIR "/ecncheck","ecncheck",flags,firedns_ntoa6(ip6),portstring,NULL);
	perror("execl()");
	exit(102);
}
#endif

/*
 * 1 - 6 See ecncheck (highest error of any host)
 *
 * 100 Syntax error
 * 102 System error
 */
int main(int argc, char *argv[]) {
	struct firedns_mxlist *mxlist, *iter;
	int fds[MAX_FDS];
	int i;
	int ret = 0;

	if (argc == 3 && argv[1][0] == '-') {
		int i = 1;
		while (argv[1][i] != '\0') {
			switch (argv[1][i]) {
				case 'x':
					xml = 1;
					break;
				case 's':
					slow = 1;
					break;
				case 'N':
					names = 0;
					break;
			}
			i++;
		}
		argc--;
		argv[1] = argv[2];
	}

	if (argc != 2) {
		printf("usage: %s [-xsN] <domain>\n",argv[0]);
		return 100;
	}

	mxlist = firedns_resolvemxalist(argv[1]);

	if (mxlist == NULL) {
		printf("Unable to look up MX list for %s\n",argv[1]);
		return 103;
	}

	iter = mxlist;
	i = 0;
	while (iter != NULL) {
		struct firedns_ip4list *ipiter;
#ifdef HAVE_IPV6
		struct firedns_ip6list *ip6iter;
#endif

		ipiter = iter->ip4list;
		while (ipiter != NULL) {
			fds[i] = magic_popen(&ipiter->ip,firedns_mx_port[iter->protocol],i);
			if (++i >= MAX_FDS)
				return 104;
			ipiter = ipiter->next;
			if (slow)
				sleep(1);
		}

#ifdef HAVE_IPV6
		ip6iter = iter->ip6list;
		while (ip6iter != NULL) {
			fds[i] = magic_popen6(&ip6iter->ip,firedns_mx_port[iter->protocol],i);
			if (++i >= MAX_FDS)
				return 104;
			ip6iter = ip6iter->next;
			if (slow)
				sleep(1);
		}
#endif

		iter = iter->next;
	}

	if (xml)
		printf("<?xml version=\"1.0\"?>\n"
				"<ecnmx time=\"%d\" domain=\"%s\">\n",(int)time(NULL),argv[1]);

	iter = mxlist;
	i = 0;
	while (iter != NULL) {
		struct firedns_ip4list *ipiter;
#ifdef HAVE_IPV6
		struct firedns_ip6list *ip6iter;
#endif

		if (xml)
			printf("	<mx hostname=\"%s\" protocol=\"%s\" priority=\"%d\" port=\"%d\">\n",iter->name,firedns_mx_name[iter->protocol],iter->priority,firedns_mx_port[iter->protocol]);
		else
			printf("=======> %7s (%05d) %s:%d\n",firedns_mx_name[iter->protocol],iter->priority,iter->name,firedns_mx_port[iter->protocol]);

		ipiter = iter->ip4list;
		while (ipiter != NULL) {
			char buffer[4096];
			int l;

			if (xml)
				printf("		<ip version=\"4\">%s\n",firedns_ntoa4(&ipiter->ip));
			else
				printf("----> %s\n",firedns_ntoa4(&ipiter->ip));

			fflush(stdout);
			while ((l = read(fds[i],buffer,4096)) > 0)
				write(1,buffer,l);
			close(fds[i]);
			if (waitpid(pids[i],&l,0) <= 0) {
				perror("waitpid()");
				exit(102);
			}
			if (!WIFEXITED(l)) {
				printf("Child exited abnormally\n");
				exit(102);
			}
			ret = max(ret,WEXITSTATUS(l));

			if (xml)
				printf("		</ip>\n");

			i++;
			ipiter = ipiter->next;
			if (!xml)
				printf("\n");
		}

#ifdef HAVE_IPV6
		ip6iter = iter->ip6list;
		while (ip6iter != NULL) {
			char buffer[4096];
			int l;

			if (xml)
				printf("		<ip version=\"6\">%s\n",firedns_ntoa6(&ip6iter->ip));
			else
				printf("----> %s\n",firedns_ntoa6(&ip6iter->ip));

			fflush(stdout);
			while ((l = read(fds[i],buffer,4096)) > 0)
				write(1,buffer,l);
			close(fds[i]);
			if (waitpid(pids[i],&l,0) <= 0) {
				perror("waitpid()");
				exit(102);
			}
			if (!WIFEXITED(l)) {
				printf("Child exited abnormally\n");
				exit(102);
			}
			ret = max(ret,WEXITSTATUS(l));

			if (xml)
				printf("		</ip>\n");

			i++;
			ip6iter = ip6iter->next;
			if (!xml)
				printf("\n");
		}
#endif

		if (xml)
			printf("	</mx>\n");
		iter = iter->next;
		if (iter && !xml)
			printf("\n");
	}

	if (xml)
		printf("</ecnmx>\n");

	return ret;
}
