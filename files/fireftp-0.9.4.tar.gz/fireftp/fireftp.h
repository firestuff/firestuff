/*
fireftp.h - FireFTP common defines
Copyright (C) 2000 Ian Gulliver

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#define FIREFTP_PASSWD "/etc/fireftp/passwd"
#define FIREFTP_ACCESSLIST "/etc/fireftp/accesslist"
#define FIREFTP_TIMEOUT 300
#define FIREFTP_TRANSFERBUFFER 65536

#define FIREFTP_GREETING "220 FireFTP " VERSION "\r\n"
#define FIREFTP_NEEDPASS "331 need password\r\n"
#define FIREFTP_LOGGEDIN "230 welcome\r\n"
#define FIREFTP_NOTLOGGEDIN "530 invalid username or password\r\n"
#define FIREFTP_BADCOMMAND "500 bad command\r\n"
#define FIREFTP_GOODBYE "221 goodbye\r\n"
#define FIREFTP_OK "200 ok\r\n"
#define FIREFTP_FILEACTION_OK "250 ok\r\n"
#define FIREFTP_BADARGS "501 invalid arguments\r\n"
#define FIREFTP_LOCALERROR "451 local error\r\n"
#define FIREFTP_CROSSDIR "451 actions across top-level directories prohibited\r\n"
#define FIREFTP_DATAERROR "450 data connection error\r\n"
#define FIREFTP_DATAOK "150 opening data connection\r\n"
#define FIREFTP_FNF "550 file not found\r\n"
#define FIREFTP_ISDIR "550 object is a directory\r\n"
#define FIREFTP_TIMEDOUT "421 disconected for idle timeout\r\n"

#define FIREFTP_BUFLEN 1024

struct virtdir_entry {
	char *publicname;
	char *systemname;
	struct virtdir_entry *next;
};
