/*
stage1.c - FireFTP stage1 binary
Copyright (C) 2003 Ian Gulliver

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#include "firemake.h"
#include <firestring.h>
#include "fireftp.h"
#include "common.h"
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>

struct sockaddr_in remoteport = {0};
int pasv = -1;
char type = 'A';

void do_list(struct virtdir_entry *head) {
	int s;
	struct virtdir_entry *entry;
	char *t;

	s = opendata();
	if (s == -1)
		return;
	entry = head;
	while (entry != NULL) {
		t = getlsline(entry->systemname);
		if (t == NULL)
			continue;
		write(s,t,strlen(t));
		write(s,entry->publicname,strlen(entry->publicname));
		write(s,"\r\n",2);
		entry = entry->next;
	}
	close(s);
	write(1,FIREFTP_OK,sizeof(FIREFTP_OK) - 1);
}

void do_nlst(struct virtdir_entry *head) {
	int s;
	struct virtdir_entry *entry;

	s = opendata();
	if (s == -1)
		return;
	entry = head;
	while (entry != NULL) {
		write(s,entry->publicname,strlen(entry->publicname));
		write(s,"\r\n",2);
		entry = entry->next;
	}
	close(s);
	write(1,FIREFTP_OK,sizeof(FIREFTP_OK) - 1);
}

void handle_chdir(char *dir, struct virtdir_entry *head) {
	char *slash;
	struct virtdir_entry *entry;
	pid_t p;
	int i;

	if (dir[0] == '/')
		dir++;

	slash = strchr(dir,'/');
	if (slash != NULL)
		*slash = '\0';

	entry = head;
	while (entry != NULL) {
		if (strcmp(entry->publicname,dir) == 0)
			goto gotchdir;
		entry = entry->next;
	}
	write(1,FIREFTP_FNF,sizeof(FIREFTP_FNF) - 1);
	return;

gotchdir:
	p = fork();
	if (p == -1) {
		write(1,FIREFTP_LOCALERROR,sizeof(FIREFTP_LOCALERROR) - 1);
		return;
	}

	if (p) {
		if (waitpid(p,&i,0) == -1)
			exit(0);
		if (!WIFEXITED(i) || WEXITSTATUS(i))
			exit(0);
	} else {
		/* child */
		char pasvstring[32];
		char typestring[2];
		firestring_snprintf(pasvstring,32,"%d",pasv);
		typestring[0] = type;
		typestring[1] = '\0';
		if (slash == NULL)
			execlp("fireftp2","fireftp2",entry->publicname,entry->systemname,pasvstring,typestring,NULL);
		else {
			*slash = '/';
			execlp("fireftp2","fireftp2",entry->publicname,entry->systemname,pasvstring,typestring,slash,NULL);
		}
		exit(1);
	}
}

int auth_user(char *username, char *password) {
	FILE *f;
	char line[1024];
	char *colon;

	f = fopen(FIREFTP_PASSWD,"r");
	if (f == NULL)
		return 1;

	while (fgets(line,1024,f) != NULL) {
		colon = strchr(line,'\n');
		if (colon == NULL)
			continue;
		*colon = '\0';
		colon = strchr(line,':');
		if (colon == NULL)
			continue;
		*(colon++) = '\0';
		if (strcmp(line,username) != 0)
			continue;
		if (strcmp(crypt(password,colon),colon) == 0) {
			fclose(f);
			return 0;
		}
	}

	fclose(f);
	return 1;
}

struct virtdir_entry *build_virtdir(char *username) {
	struct virtdir_entry *head = NULL, *tail = NULL;
	FILE *f;
	char line[1024];
	char *systemname, *publicname;
	struct stat s;

	f = fopen(FIREFTP_ACCESSLIST,"r");
	if (f == NULL)
		return NULL;

	while (fgets(line,1024,f) != NULL) {
		systemname = strchr(line,'\n');
		if (systemname == NULL)
			continue;
		*systemname = '\0';
		systemname = strchr(line,':');
		if (systemname == NULL)
			continue;
		*(systemname++) = '\0';
		if (strcmp(line,username) != 0)
			continue;
		publicname = strchr(systemname,':');
		if (publicname == NULL)
			continue;
		*(publicname++) = '\0';
		if (stat(systemname,&s))
			continue;
		if (tail == NULL) {
			head = tail = firestring_malloc(sizeof(struct virtdir_entry));
		} else {
			tail->next = firestring_malloc(sizeof(struct virtdir_entry));
			tail = tail->next;
		}
		tail->publicname = firestring_strdup(publicname);
		tail->systemname = firestring_strdup(systemname);
		tail->next = NULL;
	}

	fclose(f);

	return head;
}

int main() {
	char username[FIREFTP_BUFLEN] = "";
	char *s;
	struct virtdir_entry *virtdir;

	initport();

	write(1,FIREFTP_GREETING,sizeof(FIREFTP_GREETING) - 1);

getuser:
	s = getcommand();
	if (firestring_strncasecmp(s,"USER ",5) != 0) {
		write(1,FIREFTP_BADCOMMAND,sizeof(FIREFTP_BADCOMMAND) - 1);
		goto getuser;
	}
	strcpy(username,&s[5]);
	write(1,FIREFTP_NEEDPASS,sizeof(FIREFTP_NEEDPASS) - 1);

getpass:
	s = getcommand();
	if (firestring_strncasecmp(s,"PASS ",5) != 0) {
		write(1,FIREFTP_BADCOMMAND,sizeof(FIREFTP_BADCOMMAND) - 1);
		goto getpass;
	}

	/* got credentials, authenticate */
	if (auth_user(username,&s[5])) {
		fprintf(stderr,"FIREFTP: Password failure for '%s': '%s'\n",username,&s[5]);
		write(1,FIREFTP_NOTLOGGEDIN,sizeof(FIREFTP_NOTLOGGEDIN) - 1);
		exit(0);
	}

	fprintf(stderr,"FIREFTP: '%s' logged in\n",username);
	/* authorize (build virtual directory */
	virtdir = build_virtdir(username);

	/* welcome the client */
	write(1,FIREFTP_LOGGEDIN,sizeof(FIREFTP_LOGGEDIN) - 1);

	while (1) {
		s = getcommand();
		if (firestring_strcasecmp(s,"QUIT") == 0) {
			write(1,FIREFTP_GOODBYE,sizeof(FIREFTP_GOODBYE) - 1);
			exit(0);
		} else if (firestring_strncasecmp(s,"PORT ",5) == 0) {
			if (storeport(&s[5]))
				write(1,FIREFTP_BADARGS,sizeof(FIREFTP_BADARGS) - 1);
			else
				write(1,FIREFTP_OK,sizeof(FIREFTP_OK) - 1);
		} else if (firestring_strcasecmp(s,"LIST") == 0) {
			do_list(virtdir);
		} else if (firestring_strcasecmp(s,"NLST") == 0) {
			do_nlst(virtdir);
		} else if (firestring_strcasecmp(s,"PWD") == 0) {
			write(1,"257 \"/\"\r\n",9);
		} else if (firestring_strncasecmp(s,"CWD ",4) == 0) {
			if (s[4] == '/' && s[5] == '\0')
				write(1,FIREFTP_FILEACTION_OK,sizeof(FIREFTP_FILEACTION_OK) - 1);
			else
				handle_chdir(&s[4],virtdir);
		} else if (firestring_strncasecmp(s,"TYPE ",5) == 0) {
			if (strchr("IA",s[5]) != NULL) {
				type = s[5];
				write(1,FIREFTP_OK,sizeof(FIREFTP_OK) - 1);
			} else
				write(1,FIREFTP_BADARGS,sizeof(FIREFTP_BADARGS) - 1);
		} else if (firestring_strcasecmp(s,"PASV") == 0) {
			setup_pasv();
		} else {
			write(1,FIREFTP_BADCOMMAND,sizeof(FIREFTP_BADCOMMAND) - 1);
		}
	}
	
	return 0;
}
