/*
stage2.c - FireFTP stage2 binary
Copyright (C) 2000 Ian Gulliver

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#include "firemake.h"
#include "fireftp.h"
#include "common.h"
#include <firestring.h>
#include <firedns.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/sendfile.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <stdio.h>

struct sockaddr_in remoteport = {0};
int pasv;
char type;

int strip_toplevel(char **dir, char *toplevel) {
	char *mydir = *dir;
	int i,l;

	l = strlen(mydir);
	if (mydir[0] == '/') {
		i = strlen(toplevel);
		if (l <= i || strncmp(&mydir[1],toplevel,i) || (mydir[i + 1] != '/' && mydir[i + 1] != '\0')) {
			write(1,FIREFTP_CROSSDIR,sizeof(FIREFTP_CROSSDIR) - 1);
			return 1;
		}
		i++;
		if (mydir[i] == '\0') {
			i = 0;
			strcpy(mydir,"/");
		}
		*dir += i;
	}

	return 0;
}

void do_nlst(char *dir, char *ourpublic) {
	int s;
	DIR *d;
	struct dirent *entry;

	if (strip_toplevel(&dir,ourpublic))
		return;

	s = opendata();
	if (s == -1)
		return;
	d = opendir(dir);
	while ((entry = readdir(d)) != NULL) {
		write(s,entry->d_name,strlen(entry->d_name));
		write(s,"\r\n",2);
	}
	close(s);
	write(1,FIREFTP_OK,sizeof(FIREFTP_OK) - 1);
}

void do_list(char *dir, char *ourpublic) {
	int s;
	DIR *d;
	struct dirent *entry;
	char *t;
	char buffer[1024];

	if (strip_toplevel(&dir,ourpublic))
		return;

	getcwd(buffer,1024);
	if (chdir(dir)) {
		write(1,FIREFTP_FNF,sizeof(FIREFTP_FNF) - 1);
		return;
	}

	s = opendata();
	if (s == -1)
		return;
	d = opendir(".");
	while ((entry = readdir(d)) != NULL) {
		t = getlsline(entry->d_name);
		if (t == NULL)
			continue;
		write(s,t,strlen(t));
		write(s,entry->d_name,strlen(entry->d_name));
		write(s,"\r\n",2);
	}
	close(s);
	chdir(buffer);
	write(1,FIREFTP_OK,sizeof(FIREFTP_OK) - 1);
}

void do_chdir(char *dir, char *ourpublic) {
	char buffer[1024];
	if (dir[0] == '/' && dir[1] == '\0') {
		write(1,FIREFTP_FILEACTION_OK,sizeof(FIREFTP_FILEACTION_OK) - 1);
		exit(0);
	}

	if (strip_toplevel(&dir,ourpublic))
		return;

	if (strcmp(dir,"..") == 0 && strlen(getcwd(buffer,1024)) == 1) {
		write(1,FIREFTP_FILEACTION_OK,sizeof(FIREFTP_FILEACTION_OK) - 1);
		exit(0);
	}

	if (chdir(dir)) {
		write(1,FIREFTP_FNF,sizeof(FIREFTP_FNF) - 1);
		return;
	}
	write(1,FIREFTP_FILEACTION_OK,sizeof(FIREFTP_FILEACTION_OK) - 1);
}

void do_mkdir(char *dir, char *ourpublic) {
	if (strip_toplevel(&dir,ourpublic))
		return;

	if (mkdir(dir,0777)) {
		write(1,FIREFTP_FNF,sizeof(FIREFTP_FNF) - 1);
		return;
	}
	write(1,FIREFTP_FILEACTION_OK,sizeof(FIREFTP_FILEACTION_OK) - 1);
}

void do_rmdir(char *dir, char *ourpublic) {
	if (strip_toplevel(&dir,ourpublic))
		return;

	if (rmdir(dir)) {
		write(1,FIREFTP_FNF,sizeof(FIREFTP_FNF) - 1);
		return;
	}
	write(1,FIREFTP_FILEACTION_OK,sizeof(FIREFTP_FILEACTION_OK) - 1);
}

void do_unlink(char *dir, char *ourpublic) {
	if (strip_toplevel(&dir,ourpublic))
		return;

	if (unlink(dir)) {
		write(1,FIREFTP_FNF,sizeof(FIREFTP_FNF) - 1);
		return;
	}
	write(1,FIREFTP_FILEACTION_OK,sizeof(FIREFTP_FILEACTION_OK) - 1);
}

void do_chmod(char *dir, char *ourpublic) {
	char *realdir;
	unsigned int o;

	realdir = strchr(dir,' ');
	if (realdir == NULL) {
		write(1,FIREFTP_BADARGS,sizeof(FIREFTP_BADARGS) - 1);
		return;
	}
	*(realdir++) = '\0';

	if (strip_toplevel(&realdir,ourpublic))
		return;

	if (strlen(dir) != 3 || sscanf(dir,"%o",&o) != 1) {
		write(1,FIREFTP_BADARGS,sizeof(FIREFTP_BADARGS) - 1);
		return;
	}

	if (chmod(realdir,o)) {
		write(1,FIREFTP_FNF,sizeof(FIREFTP_FNF) - 1);
		return;
	}
	write(1,FIREFTP_FILEACTION_OK,sizeof(FIREFTP_FILEACTION_OK) - 1);
}

void do_sendfile(char *dir, char *ourpublic) {
	int i;
	int d;
	struct stat s;

	if (strip_toplevel(&dir,ourpublic))
		return;

	if (stat(dir,&s)) {
		write(1,FIREFTP_FNF,sizeof(FIREFTP_FNF) - 1);
		return;
	}

	if (S_ISDIR(s.st_mode)) {
		write(1,FIREFTP_ISDIR,sizeof(FIREFTP_ISDIR) - 1);
		return;
	}

	i = open(dir,O_RDONLY);
	if (i == -1) {
		write(1,FIREFTP_FNF,sizeof(FIREFTP_FNF) - 1);
		return;
	}
	d = opendata();
	if (d == -1)
		return;
	if (type == 'I') {
		off_t o = 0;
		int m;
		if (fstat(i,&s)) {
			close(d);
			write(1,FIREFTP_LOCALERROR,sizeof(FIREFTP_LOCALERROR) - 1);
			return;
		}
		m = sendfile(d,i,&o,s.st_size);
		if (m == -1) {
			close(d);
			write(1,FIREFTP_DATAERROR,sizeof(FIREFTP_DATAERROR) - 1);
			return;
		}
	} else {
		char buffer[FIREFTP_TRANSFERBUFFER];
		int j,k,o;
		/* ascii, slow copy to do translation */
		while ((o = read(i,buffer,FIREFTP_TRANSFERBUFFER)) > 0) {
			k = 0;
			for (j = 0; j < o; j++) {
				if (buffer[j] == '\n') {
					write(d,&buffer[k],j - k);
					write(d,"\r\n",2);
					k = j + 1;
				}
			}
		}
	}
	close(d);
	write(1,FIREFTP_OK,sizeof(FIREFTP_OK) - 1);
}

void do_recvfile(char *dir, char *ourpublic) {
	int i;
	int d;
	int o;
	char buffer[FIREFTP_TRANSFERBUFFER];

	if (strip_toplevel(&dir,ourpublic))
		return;

	i = open(dir,O_WRONLY | O_CREAT | O_TRUNC,0777);
	if (i == -1) {
		write(1,FIREFTP_FNF,sizeof(FIREFTP_FNF) - 1);
		return;
	}
	d = opendata();
	if (d == -1)
		return;
	while ((o = read(d,buffer,FIREFTP_TRANSFERBUFFER)) > 0) {
		if (type == 'A') {
			int j;
			for (j = 0; j < o; j++) {
				if (buffer[j] == '\r') {
					memmove(&buffer[j],&buffer[j + 1],o - j);
					o--;
				}
			}
		}
		if (write(i,buffer,o) != o) {
			close(d);
			write(1,FIREFTP_DATAERROR,sizeof(FIREFTP_DATAERROR) - 1);
			return;
		}
	}
	close(d);
	write(1,FIREFTP_OK,sizeof(FIREFTP_OK) - 1);
}

int main(int argc, char *argv[]) {
	struct stat st;
	char buf[1024];
	char *s;

	initport();

	if (argc < 5) {
		write(1,FIREFTP_LOCALERROR,sizeof(FIREFTP_LOCALERROR) - 1);
		exit(0);
	}

	if (chroot(argv[2])) {
		write(1,FIREFTP_LOCALERROR,sizeof(FIREFTP_LOCALERROR) - 1);
		exit(0);
	}

	if (chdir("/")) {
		write(1,FIREFTP_LOCALERROR,sizeof(FIREFTP_LOCALERROR) - 1);
		exit(0);
	}

	if (stat(".",&st)) {
		write(1,FIREFTP_LOCALERROR,sizeof(FIREFTP_LOCALERROR) - 1);
		exit(0);
	}

	if (st.st_uid == 0 || st.st_gid == 0) {
		write(1,FIREFTP_LOCALERROR,sizeof(FIREFTP_LOCALERROR) - 1);
		exit(0);
	}

	if (setgid(st.st_gid)) {
		write(1,FIREFTP_LOCALERROR,sizeof(FIREFTP_LOCALERROR) - 1);
		exit(0);
	}

	if (setuid(st.st_uid)) {
		write(1,FIREFTP_LOCALERROR,sizeof(FIREFTP_LOCALERROR) - 1);
		exit(0);
	}

	pasv = atoi(argv[3]);
	type = argv[4][0];

	if (argc == 6) {
		if (chdir(argv[5])) {
			write(1,FIREFTP_FNF,sizeof(FIREFTP_FNF) - 1);
			exit(0);
		}
	}

	write(1,FIREFTP_FILEACTION_OK,sizeof(FIREFTP_FILEACTION_OK) - 1);

	while (1) {
		s = getcommand();
		if (firestring_strcasecmp(s,"QUIT") == 0) {
			write(1,FIREFTP_GOODBYE,sizeof(FIREFTP_GOODBYE) - 1);
			exit(1);
		} else if (firestring_strncasecmp(s,"PORT ",5) == 0) {
			if (storeport(&s[5]))
				write(1,FIREFTP_BADARGS,sizeof(FIREFTP_BADARGS) - 1);
			else
				write(1,FIREFTP_OK,sizeof(FIREFTP_OK) - 1);
		} else if (firestring_strcasecmp(s,"PASV") == 0) {
			setup_pasv();
		} else if (firestring_strcasecmp(s,"NLST") == 0) {
			do_nlst(".",argv[1]);
		} else if (firestring_strcasecmp(s,"LIST") == 0) {
			do_list(".",argv[1]);
		} else if (firestring_strncasecmp(s,"NLST ",5) == 0) {
			do_nlst(&s[5],argv[1]);
		} else if (firestring_strncasecmp(s,"LIST ",5) == 0) {
			do_list(&s[5],argv[1]);
		} else if (firestring_strncasecmp(s,"TYPE ",5) == 0) {
			if (strchr("IA",s[5]) != NULL) {
				type = s[5];
				write(1,FIREFTP_OK,sizeof(FIREFTP_OK) - 1);
			} else
				write(1,FIREFTP_BADARGS,sizeof(FIREFTP_BADARGS) - 1);
		} else if (firestring_strcasecmp(s,"CDUP") == 0) {
			if (strlen(getcwd(buf,1024)) == 1) {
				write(1,FIREFTP_FILEACTION_OK,sizeof(FIREFTP_FILEACTION_OK) - 1);
				exit(0);
			} else {
				if (chdir(".."))
					write(1,FIREFTP_LOCALERROR,sizeof(FIREFTP_LOCALERROR) - 1);
				else
					write(1,FIREFTP_FILEACTION_OK,sizeof(FIREFTP_FILEACTION_OK) - 1);
			}
		} else if (firestring_strncasecmp(s,"CWD ",4) == 0) {
			do_chdir(&s[4],argv[1]);
		} else if (firestring_strncasecmp(s,"MKD ",4) == 0) {
			do_mkdir(&s[4],argv[1]);
		} else if (firestring_strncasecmp(s,"RMD ",4) == 0) {
			do_rmdir(&s[4],argv[1]);
		} else if (firestring_strncasecmp(s,"DELE ",5) == 0) {
			do_unlink(&s[5],argv[1]);
		} else if (firestring_strncasecmp(s,"RETR ",5) == 0) {
			do_sendfile(&s[5],argv[1]);
		} else if (firestring_strncasecmp(s,"STOR ",5) == 0) {
			do_recvfile(&s[5],argv[1]);
		} else if (firestring_strncasecmp(s,"SITE CHMOD ",11) == 0) {
			do_chmod(&s[11],argv[1]);
		} else if (firestring_strcasecmp(s,"PWD") == 0) {
			write(1,"257 \"/",6);
			write(1,argv[1],strlen(argv[1]));
			s = getcwd(buf,1024);
			write(1,s,strlen(s));
			if (strlen(s) > 1)
				write(1,"/",1);
			write(1,"\"\r\n",3);
		} else {
			write(1,FIREFTP_BADCOMMAND,sizeof(FIREFTP_BADCOMMAND) - 1);
		}
	}

	return 0;
}
