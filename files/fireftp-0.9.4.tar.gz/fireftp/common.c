/*
common.c - FireFTP common functions
Copyright (C) 2000 Ian Gulliver

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#include "firemake.h"
#include "fireftp.h"
#include <firestring.h>
#include <stdlib.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <stdio.h>
#include <time.h>

extern struct sockaddr_in remoteport;
extern int pasv;

/* if environment variables are available, initialize the remote port information from them */
void initport() {
	char *ip, *port;

	ip = getenv("TCPREMOTEIP");
	port = getenv("TCPREMOTEPORT");
	
	if (ip == NULL || port == NULL)
		return;

	remoteport.sin_family = AF_INET;
	remoteport.sin_port = htons(atoi(port));
	firedns_aton4_s(ip,&remoteport.sin_addr);
}

/* hoorah for no pipelining! */
char *getcommand() {
	static char buffer[FIREFTP_BUFLEN];
	fd_set readset;
	struct timeval tv;
	int length = 0;
	int i;

	tv.tv_usec = 0;
	tv.tv_sec = FIREFTP_TIMEOUT;
	FD_ZERO(&readset);
	FD_SET(0,&readset);

	i = select(1,&readset,NULL,NULL,&tv);
	if (i == 0) {
		write(1,FIREFTP_TIMEDOUT,sizeof(FIREFTP_TIMEDOUT) - 1);
		exit(1);
	}

getcommand_reread:
	i = read(0,buffer,FIREFTP_BUFLEN - length - 1);
	if (i == 0) /* client quit */
		exit(0);

	length += i;

	if (buffer[length - 2] == '\r' && buffer[length - 1] == '\n') {
		buffer[length - 2] = '\0';
		return buffer;
	}

	goto getcommand_reread;
}

int storeport(char *args) {
	char *comma, *comma2;
	int i;

	if (pasv != -1) {
		close(pasv);
		pasv = -1;
	}
	comma = args;
	for (i = 0; i < 4; i++) {
		comma2 = strchr(comma,',');
		if (comma2 == NULL)
			return 1;
		*(comma2++) = '\0';
		((unsigned char *)&remoteport.sin_addr.s_addr)[i] = atoi(comma);
		comma = comma2;
	}

	comma2 = strchr(comma,',');
	if (comma2 == NULL)
		return 1;
	*(comma2++) = '\0';
	i = (atoi(comma) << 8) + atoi(comma2);
	if (i < 1024)
		return 1;
	remoteport.sin_port = htons(i);
	remoteport.sin_family = AF_INET;

	return 0;
}

void setup_pasv() {
	int i;
	unsigned int u;
	char buffer[1024];
	struct sockaddr_in localport;

	if (pasv != -1)
		close(pasv);
	pasv = socket(PF_INET,SOCK_STREAM,0);
	if (pasv == -1) {
		write(1,FIREFTP_LOCALERROR,sizeof(FIREFTP_LOCALERROR) - 1);
		return;
	}
	u = sizeof(remoteport);
	if (getsockname(0,(struct sockaddr *)&localport,&u)) {
		write(1,FIREFTP_LOCALERROR,sizeof(FIREFTP_LOCALERROR) - 1);
		return;
	}
	if (listen(pasv,1)) {
		write(1,FIREFTP_LOCALERROR,sizeof(FIREFTP_LOCALERROR) - 1);
		return;
	}
	u = sizeof(remoteport);
	if (getsockname(pasv,(struct sockaddr *)&remoteport,&u)) {
		write(1,FIREFTP_LOCALERROR,sizeof(FIREFTP_LOCALERROR) - 1);
		return;
	}
	memcpy(&remoteport.sin_addr.s_addr,&localport.sin_addr.s_addr,sizeof(remoteport.sin_addr.s_addr));
	i = sprintf(buffer,"227 Entering Passive Mode (%d,%d,%d,%d,%d,%d).\r\n",
			((unsigned char *)&remoteport.sin_addr.s_addr)[0],
			((unsigned char *)&remoteport.sin_addr.s_addr)[1],
			((unsigned char *)&remoteport.sin_addr.s_addr)[2],
			((unsigned char *)&remoteport.sin_addr.s_addr)[3],
			ntohs(remoteport.sin_port) >> 8,
			ntohs(remoteport.sin_port) % 256);
	write(1,buffer,i);
	return;
}

int opendata() {
	int s;

	write(1,FIREFTP_DATAOK,sizeof(FIREFTP_DATAOK) - 1);
	if (pasv == -1) {
		s = socket(PF_INET,SOCK_STREAM,0);
		if (s == -1) {
			write(1,FIREFTP_LOCALERROR,sizeof(FIREFTP_LOCALERROR) - 1);
			return -1;
		}
		if (connect(s,(struct sockaddr *)&remoteport,sizeof(remoteport))) {
			write(1,FIREFTP_DATAERROR,sizeof(FIREFTP_DATAERROR) - 1);
			return -1;
		}
	} else {
		s = accept(pasv,NULL,NULL);
		if (s == -1) {
			write(1,FIREFTP_DATAERROR,sizeof(FIREFTP_DATAERROR) - 1);
			return -1;
		}
		pasv = -1;
	}
	return s;
}

static const char *months[] = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };

char *getdate(int unixtime) {
	static char buf[14];
	struct tm *t;

	t = localtime((time_t *)&unixtime);
	sprintf(buf,"%s %2d  %4d",months[t->tm_mon],t->tm_mday,t->tm_year + 1900);
	return buf;
}

char *getlsline(char *file) {
	static char line[1024];
	struct stat s;

	if (lstat(file,&s))
		return NULL;

	firestring_snprintf(line,1024,"%s" "%s%s%s" "%s%s%s" "%s%s%s" "    1 you      you %13d %s ",
			S_ISDIR(s.st_mode) ? "d" : (S_ISLNK(s.st_mode) ? "l" : "-"),
			s.st_mode & S_IRUSR ? "r" : "-",
			s.st_mode & S_IWUSR ? "w" : "-",
			s.st_mode & S_IXUSR ? "x" : "-",
			s.st_mode & S_IRGRP ? "r" : "-",
			s.st_mode & S_IWGRP ? "w" : "-",
			s.st_mode & S_IXGRP ? "x" : "-",
			s.st_mode & S_IROTH ? "r" : "-",
			s.st_mode & S_IWOTH ? "w" : "-",
			s.st_mode & S_IXOTH ? "x" : "-",
			s.st_size,
			getdate(s.st_mtime));
	return line;
}
